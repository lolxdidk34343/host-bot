import asyncio
from datetime import datetime, timedelta
from typing import Dict, Optional

class TimerManager:
    """Manages prediction timers and auto-close functionality"""
    
    active_timers: Dict[str, Dict] = {}
    custom_durations: Dict[str, int] = {}  # system_name -> minutes
    
    @staticmethod
    async def start_prediction_timer(system_name: str, ctx, duration_minutes: int = 4):
        """Start a timer for a prediction system"""
        # Use custom duration if set
        if system_name in TimerManager.custom_durations:
            duration_minutes = TimerManager.custom_durations[system_name]
        
        end_time = datetime.now() + timedelta(minutes=duration_minutes)
        
        # Cancel existing timer
        TimerManager.cancel_timer(system_name)
        
        # Store timer info
        TimerManager.active_timers[system_name] = {
            'end_time': end_time,
            'ctx': ctx,
            'duration': duration_minutes
        }
        
        # Start countdown task
        task = asyncio.create_task(TimerManager._countdown_task(system_name, ctx, duration_minutes))
        TimerManager.active_timers[system_name]['task'] = task
    
    @staticmethod
    async def _countdown_task(system_name: str, ctx, duration_minutes: int):
        """Internal countdown task"""
        try:
            await asyncio.sleep(duration_minutes * 60)
            
            # Auto-close predictions
            from main import prediction_systems
            if prediction_systems[system_name]['active']:
                prediction_systems[system_name]['active'] = False
                
                # Get prediction count
                prediction_count = len(prediction_systems[system_name]['predictions'])
                
                # Send auto-close message
                await ctx.send(f"⏰ **{system_name.upper()} predictions AUTO-CLOSED!** ({prediction_count} predictions recorded)")
                
                # Stop activity monitoring
                from activity_monitor import ActivityMonitor
                ActivityMonitor.stop_reminder_monitoring(system_name)
                
                # Delete pending messages
                from admin_utils import AdminUtils
                await AdminUtils.delete_pending_messages(system_name)
                
                # Clear usernames from validator
                from user_validator import UserValidator
                await UserValidator.clear_system_usernames(system_name)
                
                # Save data
                from persistence_manager import PersistenceManager
                await PersistenceManager.save_data()
            
            # Clean up timer
            if system_name in TimerManager.active_timers:
                del TimerManager.active_timers[system_name]
                
        except asyncio.CancelledError:
            pass  # Timer was cancelled
        except Exception as e:
            print(f"Error in countdown task for {system_name}: {e}")
    
    @staticmethod
    def cancel_timer(system_name: str):
        """Cancel a timer for a prediction system"""
        if system_name in TimerManager.active_timers:
            timer_info = TimerManager.active_timers[system_name]
            if 'task' in timer_info:
                timer_info['task'].cancel()
            del TimerManager.active_timers[system_name]
    
    @staticmethod
    def get_time_remaining_formatted(system_name: str) -> str:
        """Get formatted time remaining for a prediction system"""
        if system_name not in TimerManager.active_timers:
            return "00:00"
        
        end_time = TimerManager.active_timers[system_name]['end_time']
        now = datetime.now()
        
        if now >= end_time:
            return "00:00"
        
        remaining = end_time - now
        minutes = int(remaining.total_seconds() // 60)
        seconds = int(remaining.total_seconds() % 60)
        
        return f"{minutes:02d}:{seconds:02d}"
    
    @staticmethod
    def get_discord_timestamp(system_name: str) -> Optional[str]:
        """Get Discord timestamp format for a prediction system"""
        if system_name not in TimerManager.active_timers:
            return None
        
        end_time = TimerManager.active_timers[system_name]['end_time']
        timestamp = int(end_time.timestamp())
        
        return f"<t:{timestamp}:R>"
    
    @staticmethod
    def set_custom_duration(system_name: str, duration_minutes: int):
        """Set custom duration for a prediction system"""
        TimerManager.custom_durations[system_name] = duration_minutes
    
    @staticmethod
    def get_custom_duration(system_name: str) -> int:
        """Get custom duration for a prediction system"""
        return TimerManager.custom_durations.get(system_name, 4)
    
    @staticmethod
    async def restore_timers():
        """Restore active timers after bot restart"""
        from main import prediction_systems
        
        for system_name, system_data in prediction_systems.items():
            if system_data.get('active') and system_data.get('timer_end_time'):
                try:
                    end_time = datetime.fromisoformat(system_data['timer_end_time'])
                    now = datetime.now()
                    
                    if end_time > now:
                        # Timer still active, restore it
                        remaining_seconds = (end_time - now).total_seconds()
                        remaining_minutes = remaining_seconds / 60
                        
                        # Create a mock context for restoration
                        class MockContext:
                            def __init__(self, bot):
                                self.bot = bot
                            
                            async def send(self, message):
                                # Find appropriate channel to send message
                                # This would need proper channel restoration logic
                                pass
                        
                        # Note: This is a simplified restoration
                        # In a real implementation, you'd need to properly restore the context
                        print(f"Restored timer for {system_name}: {remaining_minutes:.1f} minutes remaining")
                    else:
                        # Timer expired, close predictions
                        system_data['active'] = False
                        print(f"Expired timer for {system_name}, closed predictions")
                        
                except Exception as e:
                    print(f"Error restoring timer for {system_name}: {e}")
