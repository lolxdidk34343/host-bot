import discord
from discord.ext import commands
import random
import json
from datetime import datetime
from admin_utils import AdminUtils
from timer_manager import TimerManager
from activity_monitor import ActivityMonitor
from persistence_manager import PersistenceManager
from statistics_manager import StatisticsManager
from user_validator import UserValidator

class BlackjackCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def check_blackjack_prediction_winners(self, ctx, winner):
        from main import prediction_systems
        
        predictions = prediction_systems['blackjack']['predictions']
        winners = []
        kick_usernames_only = []
        all_participants = []
        total_players = len(predictions)

        # Convert game result to prediction format
        if winner == "player":
            result = "win"
        elif winner == "dealer":
            result = "lose"
        else:
            result = "lose"

        for user_id, prediction_data in predictions.items():
            user_prediction = prediction_data["prediction"]
            user = prediction_data["user"]
            kick_username = prediction_data.get("kick_username", "Unknown")
            all_participants.append(kick_username)

            # Check if prediction matches
            won = False
            if user_prediction == result:
                won = True

            if won:
                kick_usernames_only.append(kick_username)

        # Send results in friendly copy-paste box format
        if kick_usernames_only:
            winner_list = "\n".join(kick_usernames_only)
            copy_paste_box = f"```\n{winner_list}\n```"
            
            await ctx.send(f"🎉 **BLACKJACK PREDICTION WINNERS!** 🎉\n{copy_paste_box}Correctly predicted **{result.upper()}**!\n\n📊 **{len(kick_usernames_only)}/{total_players}** players won!")
        else:
            await ctx.send(f"😔 **NO BLACKJACK WINNERS!** 😔\nNone of the **{total_players}** players predicted **{result.upper()}** correctly.\nBetter luck next time!")

        # Record statistics
        await StatisticsManager.record_prediction_result('blackjack', kick_usernames_only, all_participants)

        # Clear predictions for next round
        prediction_systems['blackjack']['predictions'].clear()
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('blackjack')
        
        await PersistenceManager.save_data()

    @commands.command()
    async def bj(self, ctx):
        # Randomly determine result
        random_result = random.choice(["win", "lose"])

        # Simple result announcement
        if random_result == "win":
            result_text = "🏆 **PLAYER WINS!**"
            winner = "player"
        else:  # lose
            result_text = "💔 **PLAYER LOSES!**"
            winner = "dealer"

        # Announce result
        await ctx.send(f"""🃏 **BLACKJACK RESULT** 🃏

{result_text}

*Random result*""")

        # Check for winners if predictions were made
        from main import prediction_systems
        if prediction_systems['blackjack']['predictions']:
            await self.check_blackjack_prediction_winners(ctx, winner)

    @commands.command()
    async def bj_manual(self, ctx, custom_result: str = None):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        if custom_result is None:
            await ctx.send("❌ Please specify the result: `!bj_manual win` or `!bj_manual lose`")
            return

        custom_result = custom_result.lower()
        if custom_result not in ["win", "lose"]:
            await ctx.send("❌ Result must be: **win** or **lose**")
            return

        # Simple result announcement
        if custom_result == "win":
            result_text = "🏆 **PLAYER WINS!**"
            winner = "player"
        else:  # lose
            result_text = "💔 **PLAYER LOSES!**"
            winner = "dealer"

        # Send manual result
        await ctx.send(f"🃏 **Manual Result:** {result_text} 🔧")

        # Check for winners if predictions were made
        from main import prediction_systems
        if prediction_systems['blackjack']['predictions']:
            await self.check_blackjack_prediction_winners(ctx, winner)

    @commands.command()
    async def predictbj(self, ctx, prediction: str = None, *, kick_username: str = None):
        from main import prediction_systems
        
        # Check if wrong prediction system is being used
        error_msg = AdminUtils.check_wrong_prediction_command(ctx, 'blackjack')
        if error_msg and 'blackjack' not in AdminUtils.get_active_predictions():
            await ctx.send(error_msg)
            return

        if not prediction_systems['blackjack']['active']:
            await ctx.send("❌ Blackjack predictions are currently closed! Wait for an admin to open them.")
            return

        if not prediction or not kick_username:
            await UserValidator.send_missing_username_notification(ctx)
            await ctx.send("❌ Please specify both prediction and kick username: `!predictbj win YourKickUsername`")
            return

        # Validate kick username
        is_valid, error_msg = UserValidator.validate_kick_username(kick_username)
        if not is_valid:
            try:
                await ctx.author.send(f"**Invalid KickUsername Format**\n{error_msg}")
            except discord.Forbidden:
                pass
            await ctx.send("❌ Invalid KickUsername format! Check your DMs for details.")
            return

        # Check for username conflicts
        conflict_msg = await UserValidator.check_duplicate_username(kick_username, 'blackjack', ctx.author.id, ctx.author)
        if conflict_msg:
            try:
                await ctx.author.send(conflict_msg)
            except discord.Forbidden:
                pass
            await ctx.send("❌ Username conflict detected! Check your DMs.")
            return

        prediction = prediction.lower()
        if prediction not in ["win", "lose"]:
            await ctx.send("❌ Invalid prediction! Please choose: **win** or **lose**")
            return

        user_id = ctx.author.id
        predictions = prediction_systems['blackjack']['predictions']

        # Check if user already made a prediction
        if user_id in predictions:
            old_prediction = predictions[user_id]["prediction"]
            predictions[user_id] = {"prediction": prediction, "user": ctx.author, "kick_username": kick_username}

            # Send DM confirmation
            try:
                await ctx.author.send(f"✅ **Blackjack Prediction Updated!**\nChanged from **{old_prediction.upper()}** to **{prediction.upper()}**")
            except discord.Forbidden:
                pass  # User has DMs disabled

        else:
            # Register username
            await UserValidator.register_username(kick_username, 'blackjack', ctx.author.id, ctx.author)
            
            predictions[user_id] = {"prediction": prediction, "user": ctx.author, "kick_username": kick_username}

            # Record user participation
            await StatisticsManager.record_user_participation(kick_username, ctx.author.id, 'blackjack')

            # Send DM confirmation
            try:
                await ctx.author.send(f"✅ **Blackjack Prediction Confirmed!**\nYou predicted **{prediction.upper()}**")
            except discord.Forbidden:
                pass  # User has DMs disabled

        # Show current prediction count and list of kick usernames
        total_predictions = len(predictions)
        kick_usernames = [data["kick_username"] for data in predictions.values()]
        usernames_list = ", ".join(kick_usernames)

        await ctx.send(f"🃏 **{total_predictions}** player(s) have made blackjack predictions!\n🎮 **Players:** {usernames_list}")
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def open_bj_predictions(self, ctx):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        prediction_systems['blackjack']['active'] = True
        # Clear previous round's predictions when opening new round
        prediction_systems['blackjack']['predictions'].clear()
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('blackjack')
        
        # Get custom duration
        duration_minutes = TimerManager.get_custom_duration('blackjack')
        
        # Start timer
        await TimerManager.start_prediction_timer('blackjack', ctx, duration_minutes=duration_minutes)
        
        # Start activity monitoring
        await ActivityMonitor.start_reminder_monitoring('blackjack', ctx.channel)
        
        timestamp_str = TimerManager.get_discord_timestamp('blackjack') or f"in {duration_minutes} minutes"
        message = await ctx.send(f"✅ **Blackjack predictions are now OPEN!** 🃏\nUse `!predictbj win/lose YourKickUsername` to participate!\n⏰ **Auto-closes {timestamp_str}**")
        
        # Delete this message when predictions close
        await AdminUtils.schedule_message_deletion(message, 'blackjack')
        
        # Record statistics
        await StatisticsManager.record_prediction_opened('blackjack')
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def close_bj_predictions(self, ctx):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        prediction_systems['blackjack']['active'] = False
        prediction_count = len(prediction_systems['blackjack']['predictions'])
        
        # Cancel timer and stop activity monitoring
        TimerManager.cancel_timer('blackjack')
        ActivityMonitor.stop_reminder_monitoring('blackjack')
        
        # Delete pending messages
        await AdminUtils.delete_pending_messages('blackjack')
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('blackjack')
        
        # DON'T clear predictions yet - manual commands need them for winner checking
        await ctx.send(f"🔒 **Blackjack predictions are now CLOSED!** ({prediction_count} predictions recorded)")
        
        # Save data
        await PersistenceManager.save_data()

async def setup(bot):
    await bot.add_cog(BlackjackCog(bot))
