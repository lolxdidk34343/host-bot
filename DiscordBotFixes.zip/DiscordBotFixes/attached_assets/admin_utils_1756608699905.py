import discord
from discord.ext import commands
import asyncio

class AdminUtils:
    """Utility class for admin functions and permission checking"""
    
    ADMIN_ROLE_ID = 1397180935111184495
    pending_deletions = {}  # system_name -> [messages]
    
    @staticmethod
    def has_admin_role(user):
        """Check if user has the required admin role"""
        if not hasattr(user, 'roles'):
            return False
        
        for role in user.roles:
            if role.id == AdminUtils.ADMIN_ROLE_ID:
                return True
        return False
    
    @staticmethod
    async def check_admin_permission(ctx):
        """Check admin permission and send error if unauthorized"""
        if not AdminUtils.has_admin_role(ctx.author):
            await ctx.send("❌ You don't have permission to use this command!")
            return False
        return True
    
    @staticmethod
    def get_active_predictions():
        """Get currently active prediction systems"""
        from main import prediction_systems
        active = []
        for system, data in prediction_systems.items():
            if data['active']:
                active.append(system)
        return active
    
    @staticmethod
    async def handle_wrong_command_dm(ctx, command_used):
        """Handle wrong prediction command usage and send DM"""
        from main import prediction_systems
        
        # Check if it's a prediction command
        prediction_commands = {
            'predict': 'roulette',
            'predictbj': 'blackjack', 
            'predictblackjack': 'blackjack',
            'predictbaccarat': 'baccarat',
            'predictdice': 'dice',
            'predictlimbo': 'limbo',
            'predictmarble': 'marble',
            'predictcustom': 'custom',
            'slotcall': 'slotcall'
        }
        
        # Get active systems
        active_systems = AdminUtils.get_active_predictions()
        
        if not active_systems:
            # No predictions are open
            try:
                await ctx.author.send("❌ **Wrong Command Used**\n\nNo prediction systems are currently open! Wait for an admin to open predictions.")
            except discord.Forbidden:
                pass  # User has DMs disabled
            return
        
        # Check if the command corresponds to an inactive system
        target_system = None
        for cmd, system in prediction_commands.items():
            if command_used.startswith(cmd.lower()):
                target_system = system
                break
        
        if target_system and target_system not in active_systems:
            # User used wrong prediction command
            if len(active_systems) == 1:
                correct_command = None
                for cmd, system in prediction_commands.items():
                    if system == active_systems[0]:
                        correct_command = f"!{cmd}"
                        break
                
                message = f"❌ **Wrong Prediction Command**\n\n**{target_system.upper()}** predictions are not open!\n\nUse **{correct_command}** instead ({active_systems[0].upper()} predictions are open)."
            else:
                active_list = []
                for active_sys in active_systems:
                    for cmd, system in prediction_commands.items():
                        if system == active_sys:
                            active_list.append(f"!{cmd} ({active_sys.upper()})")
                            break
                
                message = f"❌ **Wrong Prediction Command**\n\n**{target_system.upper()}** predictions are not open!\n\n**Active predictions:**\n" + "\n".join(active_list)
            
            try:
                await ctx.author.send(message)
            except discord.Forbidden:
                pass  # User has DMs disabled
    
    @staticmethod
    def get_prediction_stats(system_name):
        """Get statistics for a specific prediction system"""
        from main import prediction_systems
        
        if system_name not in prediction_systems:
            return None
        
        system = prediction_systems[system_name]
        if not system['predictions']:
            return {"total": 0, "breakdown": {}, "active": system['active']}
        
        total = len(system['predictions'])
        breakdown = {}
        
        # Special handling for systems with multiple predictions per user
        if system_name in ['marble', 'dice', 'limbo']:
            all_predictions = []
            for user_id, prediction_data in system['predictions'].items():
                user_predictions = prediction_data['predictions']  # List of predictions
                all_predictions.extend(user_predictions)
            
            for prediction in all_predictions:
                if prediction in breakdown:
                    breakdown[prediction] += 1
                else:
                    breakdown[prediction] = 1
            
            total_predictions = len(all_predictions)
            # Calculate percentages
            for prediction in breakdown:
                breakdown[prediction] = {
                    'count': breakdown[prediction],
                    'percentage': round((breakdown[prediction] / total_predictions) * 100, 1) if total_predictions > 0 else 0
                }
            
            return {"total": total, "total_predictions": total_predictions, "breakdown": breakdown, "active": system['active']}
        
        elif system_name == 'slotcall':
            # Special handling for slot calls - just count unique usernames
            usernames = [data['kick_username'] for data in system['predictions'].values()]
            for username in usernames:
                if username in breakdown:
                    breakdown[username] += 1
                else:
                    breakdown[username] = 1
            
            # Calculate percentages
            for username in breakdown:
                breakdown[username] = {
                    'count': breakdown[username],
                    'percentage': round((breakdown[username] / total) * 100, 1)
                }
            
            return {"total": total, "breakdown": breakdown, "active": system['active']}
        
        else:
            # Count predictions by type for other systems
            for user_id, prediction_data in system['predictions'].items():
                prediction = prediction_data['prediction']
                if prediction in breakdown:
                    breakdown[prediction] += 1
                else:
                    breakdown[prediction] = 1
            
            # Calculate percentages
            for prediction in breakdown:
                breakdown[prediction] = {
                    'count': breakdown[prediction],
                    'percentage': round((breakdown[prediction] / total) * 100, 1)
                }
            
            return {"total": total, "breakdown": breakdown, "active": system['active']}
    
    @staticmethod
    async def send_prediction_stats(ctx, system_name=None):
        """Send prediction statistics to the channel (Admin only)"""
        from main import prediction_systems
        from timer_manager import TimerManager
        from statistics_manager import StatisticsManager
        
        if not AdminUtils.has_admin_role(ctx.author):
            await ctx.send("❌ You don't have permission to view statistics!")
            return
        
        if system_name:
            # Show stats for specific system
            stats = AdminUtils.get_prediction_stats(system_name)
            if not stats:
                await ctx.send(f"❌ No prediction system found: {system_name}")
                return
            
            if stats['total'] == 0:
                await ctx.send(f"📊 **{system_name.upper()} PREDICTIONS**\nNo predictions yet.")
                return
            
            embed = discord.Embed(
                title=f"📊 {system_name.upper()} PREDICTION STATS",
                color=0x9932CC if not stats['active'] else 0x00FF00
            )
            
            # Show status and timer info
            status = "🟢 OPEN" if stats['active'] else "🔴 CLOSED"
            embed.add_field(
                name="Status",
                value=status,
                inline=True
            )
            
            # Show remaining time if active (except slot calls)
            if stats['active'] and system_name != 'slotcall':
                remaining = TimerManager.get_time_remaining_formatted(system_name)
                if remaining != "00:00":
                    embed.add_field(
                        name="Time Remaining",
                        value=remaining,
                        inline=True
                    )
            
            # Total predictions
            if system_name in ['marble', 'dice', 'limbo']:
                embed.add_field(
                    name="Total Players",
                    value=f"**{stats['total']}** players\n**{stats['total_predictions']}** total predictions",
                    inline=False
                )
            else:
                embed.add_field(
                    name="Total Predictions",
                    value=f"**{stats['total']}** players",
                    inline=False
                )
            
            # Breakdown with percentages
            if stats['breakdown']:
                breakdown_text = ""
                for prediction, data in stats['breakdown'].items():
                    breakdown_text += f"**{prediction}**: {data['count']} ({data['percentage']}%)\n"
                
                embed.add_field(
                    name="Breakdown",
                    value=breakdown_text,
                    inline=False
                )
            
            await ctx.send(embed=embed)
        
        else:
            # Show comprehensive statistics
            overall_stats = await StatisticsManager.get_overall_statistics()
            
            embed = discord.Embed(
                title="📊 COMPREHENSIVE PREDICTION STATISTICS",
                color=0x9932CC
            )
            
            # Overall statistics
            embed.add_field(
                name="📈 Overall Statistics",
                value=f"**Total Predictions Opened:** {overall_stats['total_predictions_opened']}\n"
                      f"**Total Users Participated:** {overall_stats['total_users_joined']}\n"
                      f"**Total Winners:** {overall_stats['total_users_won']}\n"
                      f"**Total Losers:** {overall_stats['total_users_lost']}",
                inline=False
            )
            
            # Top winner
            if overall_stats['top_winner']:
                embed.add_field(
                    name="🏆 Top Winner",
                    value=f"**{overall_stats['top_winner']['username']}** ({overall_stats['top_winner']['wins']} wins)",
                    inline=True
                )
            
            # Current active predictions
            active_predictions = []
            for system in prediction_systems.keys():
                stats = AdminUtils.get_prediction_stats(system)
                if stats and stats['active']:
                    if system in ['marble', 'dice', 'limbo']:
                        system_info = f"🟢 {system.upper()} ({stats['total']} players, {stats['total_predictions']} predictions)"
                    else:
                        system_info = f"🟢 {system.upper()} ({stats['total']} players)"
                    active_predictions.append(system_info)
            
            if active_predictions:
                embed.add_field(
                    name="🔴 Active Predictions",
                    value="\n".join(active_predictions),
                    inline=False
                )
            
            # Recent predictions breakdown
            for system in prediction_systems.keys():
                stats = AdminUtils.get_prediction_stats(system)
                if stats and stats['total'] > 0:
                    breakdown_text = ""
                    for prediction, data in stats['breakdown'].items():
                        breakdown_text += f"{prediction}: {data['count']} ({data['percentage']}%)\n"
                    
                    status = "🟢" if stats['active'] else "🔴"
                    if system in ['marble', 'dice', 'limbo']:
                        system_info = f"{status} {system.upper()} ({stats['total']} players, {stats['total_predictions']} predictions)"
                    else:
                        system_info = f"{status} {system.upper()} ({stats['total']} players)"
                    
                    embed.add_field(
                        name=system_info,
                        value=breakdown_text or "No predictions",
                        inline=True
                    )
            
            await ctx.send(embed=embed)
    
    @staticmethod
    def check_wrong_prediction_command(ctx, correct_system):
        """Check if user is using wrong prediction command and provide helpful error"""
        from main import prediction_systems
        
        active_systems = AdminUtils.get_active_predictions()
        
        if not active_systems:
            return "❌ No prediction systems are currently open!"
        
        if correct_system not in active_systems:
            if len(active_systems) == 1:
                return f"❌ Wrong prediction command! Use `!predict{active_systems[0]}` instead."
            else:
                return f"❌ Wrong prediction command! Active systems: {', '.join(active_systems)}"
        
        return None  # No error
    
    @staticmethod
    async def schedule_message_deletion(message, system_name):
        """Schedule a message for deletion when predictions close"""
        if system_name not in AdminUtils.pending_deletions:
            AdminUtils.pending_deletions[system_name] = []
        
        AdminUtils.pending_deletions[system_name].append(message)
    
    @staticmethod
    async def delete_pending_messages(system_name):
        """Delete all pending messages for a system"""
        if system_name in AdminUtils.pending_deletions:
            for message in AdminUtils.pending_deletions[system_name]:
                try:
                    await message.delete()
                except:
                    pass  # Message might already be deleted
            
            del AdminUtils.pending_deletions[system_name]

# Add stats command to the bot
@commands.command()
async def stats(ctx, system_name: str = None):
    """Show prediction statistics (Admin only)"""
    await AdminUtils.send_prediction_stats(ctx, system_name)

@commands.command()
async def add_prediction(ctx, system_name: str, prediction: str, *, kick_username: str):
    """Add a missed prediction manually (Admin only)"""
    if not await AdminUtils.check_admin_permission(ctx):
        return
    
    from main import prediction_systems
    from persistence_manager import PersistenceManager
    from user_validator import UserValidator
    from statistics_manager import StatisticsManager
    
    if system_name not in prediction_systems:
        await ctx.send(f"❌ Invalid prediction system: {system_name}")
        return
    
    if not prediction_systems[system_name]['active']:
        await ctx.send(f"❌ {system_name.upper()} predictions are not currently active!")
        return
    
    user_id = ctx.author.id
    predictions = prediction_systems[system_name]['predictions']
    
    # Add the prediction
    if system_name in ['marble', 'dice', 'limbo']:
        # Multiple predictions per user
        try:
            prediction_value = int(prediction)
            if user_id in predictions:
                predictions[user_id]['predictions'].append(prediction_value)
            else:
                predictions[user_id] = {
                    "predictions": [prediction_value],
                    "user": ctx.author,
                    "kick_username": kick_username
                }
                # Register username and record participation for new user
                await UserValidator.register_username(kick_username, system_name, ctx.author.id, ctx.author)
                await StatisticsManager.record_user_participation(kick_username, ctx.author.id, system_name)
        except ValueError:
            await ctx.send(f"❌ Invalid prediction value for {system_name}")
            return
    else:
        # Single prediction per user
        if user_id not in predictions:
            # Register username and record participation for new user
            await UserValidator.register_username(kick_username, system_name, ctx.author.id, ctx.author)
            await StatisticsManager.record_user_participation(kick_username, ctx.author.id, system_name)
            
        predictions[user_id] = {
            "prediction": prediction,
            "user": ctx.author,
            "kick_username": kick_username
        }
    
    await ctx.send(f"✅ Added prediction for {kick_username} in {system_name.upper()}: {prediction}")
    await PersistenceManager.save_data()

# Register commands with bot instance
def setup_admin_commands(bot):
    bot.add_command(stats)
    bot.add_command(add_prediction)
