import aiohttp
import asyncio
import json
import discord
from datetime import datetime
from typing import Optional, Dict, Any

class APIMonitor:
    """Monitors the Rainbet API and updates Discord channel"""

    API_URL = "https://www.hoodieheff.com/api/rainbet"
    CHANNEL_ID = 1393451928800727070  # change to your channel id
    UPDATE_INTERVAL = 30  # seconds

    bot_instance = None
    last_data = None
    monitoring_task = None
    current_message = None

    @staticmethod
    async def initialize(bot):
        """Initialize the API monitor"""
        APIMonitor.bot_instance = bot
        APIMonitor.monitoring_task = asyncio.create_task(APIMonitor._monitoring_loop())
        print("API Monitor initialized")

    @staticmethod
    async def _monitoring_loop():
        """Main monitoring loop"""
        while True:
            try:
                await APIMonitor._check_api_update()
                await asyncio.sleep(APIMonitor.UPDATE_INTERVAL)
            except Exception as e:
                print(f"Error in API monitoring loop: {e}")
                await asyncio.sleep(60)

    @staticmethod
    async def _check_api_update():
        """Check for API updates and update Discord message if needed"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(APIMonitor.API_URL) as response:
                    if response.status == 200:
                        data = await response.json()
                        if APIMonitor._has_data_changed(data):
                            await APIMonitor._update_discord_message(data)
                            APIMonitor.last_data = data
                    else:
                        print(f"API request failed with status: {response.status}")
        except Exception as e:
            print(f"Error fetching API data: {e}")

    @staticmethod
    def _has_data_changed(new_data: Dict[str, Any]) -> bool:
        if APIMonitor.last_data is None:
            return True
        try:
            return json.dumps(new_data, sort_keys=True) != json.dumps(APIMonitor.last_data, sort_keys=True)
        except:
            return True

    @staticmethod
    async def _update_discord_message(data: Dict[str, Any]):
        try:
            channel = APIMonitor.bot_instance.get_channel(APIMonitor.CHANNEL_ID)
            if not channel:
                print(f"Could not find channel with ID: {APIMonitor.CHANNEL_ID}")
                return

            embed = await APIMonitor._create_embed_from_data(data)

            if APIMonitor.current_message:
                try:
                    await APIMonitor.current_message.edit(embed=embed)
                except Exception as e:
                    print(f"Could not edit message, creating new one: {e}")
                    APIMonitor.current_message = None

            if not APIMonitor.current_message:
                APIMonitor.current_message = await channel.send(embed=embed)
        except Exception as e:
            print(f"Error updating Discord message: {e}")

    @staticmethod
    async def _create_embed_from_data(data: Dict[str, Any]):
        try:
            affiliates = data.get("affiliates", [])
            if not affiliates:
                return discord.Embed(
                    title="🏆 Rainbet Leaderboard",
                    description="⚠️ No leaderboard data found.",
                    color=0xff0000
                )

            affiliates_sorted = sorted(
                affiliates,
                key=lambda x: float(x.get("wagered_amount", 0)),
                reverse=True
            )

            top_players = affiliates_sorted[:10]

            embed = discord.Embed(
                title="🏆 Rainbet Leaderboard",
                description="Top affiliates by wagered amount",
                color=0x00ff00,
                timestamp=datetime.now()
            )

            for i, player in enumerate(top_players, start=1):
                username = player.get("username", "Unknown")
                wagered = float(player.get("wagered_amount", 0))
                embed.add_field(
                    name=f"#{i} {username}",
                    value=f"💸 ${wagered:,.2f}",
                    inline=False
                )

            embed.set_footer(text="Last updated")
            return embed
        except Exception as e:
            print(f"Error creating embed: {e}")
            return discord.Embed(
                title="🏆 Rainbet Leaderboard",
                description="⚠️ Error processing leaderboard data",
                color=0xff0000
            )

    @staticmethod
    async def force_update():
        await APIMonitor._check_api_update()

    @staticmethod
    def stop_monitoring():
        if APIMonitor.monitoring_task:
            APIMonitor.monitoring_task.cancel()
            APIMonitor.monitoring_task = None