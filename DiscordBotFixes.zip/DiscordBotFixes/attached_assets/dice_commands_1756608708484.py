import discord
from discord.ext import commands
import random
import json
from datetime import datetime
from admin_utils import AdminUtils
from timer_manager import TimerManager
from activity_monitor import ActivityMonitor
from persistence_manager import PersistenceManager
from statistics_manager import StatisticsManager
from user_validator import UserValidator

class DiceCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def check_dice_prediction_winners(self, ctx, dice_result):
        from main import prediction_systems
        
        predictions = prediction_systems['dice']['predictions']
        winners = []
        kick_usernames_only = []
        all_participants = []
        total_players = len(predictions)
        total_predictions = 0

        for user_id, data in predictions.items():
            user = data["user"]
            user_predictions = data["predictions"]  # List of predictions
            kick_username = data["kick_username"]
            all_participants.append(kick_username)
            total_predictions += len(user_predictions)
            
            # Check if any prediction matches result (0-9)
            if str(dice_result) in [str(pred) for pred in user_predictions]:
                winners.append((user, kick_username))
                kick_usernames_only.append(kick_username)

        if winners:
            # Create copy-paste friendly winner announcement
            winner_list = "\n".join(kick_usernames_only)
            await ctx.send(f"""🏆 **DICE PREDICTION WINNERS!** 🎲

