import json
import os
import asyncio
from datetime import datetime
from typing import Dict, Any

class PersistenceManager:
    """Handles data persistence for the bot"""
    
    DATA_FILE = "predictions_data.json"
    bot_instance = None
    
    @staticmethod
    async def initialize(bot):
        """Initialize the persistence manager"""
        PersistenceManager.bot_instance = bot
    
    @staticmethod
    async def save_data():
        """Save prediction data to file"""
        try:
            from main import prediction_systems
            from timer_manager import TimerManager
            from statistics_manager import StatisticsManager
            
            # Prepare data for serialization
            data_to_save = {
                "prediction_systems": {},
                "last_updated": datetime.now().isoformat(),
                "timers": {},
                "statistics": await StatisticsManager.get_persistent_data(),
                "custom_durations": TimerManager.custom_durations
            }
            
            # Save prediction systems with serializable data
            for system_name, system_data in prediction_systems.items():
                serializable_predictions = {}
                
                for user_id, prediction_data in system_data['predictions'].items():
                    # Convert discord.User objects to user IDs and usernames
                    user = prediction_data.get('user')
                    serializable_predictions[str(user_id)] = {
                        'kick_username': prediction_data.get('kick_username', 'Unknown'),
                        'user_id': user_id,
                        'username': user.display_name if user else 'Unknown',
                    }
                    
                    # Handle different prediction formats
                    if 'prediction' in prediction_data:
                        serializable_predictions[str(user_id)]['prediction'] = prediction_data['prediction']
                    
                    if 'predictions' in prediction_data:
                        serializable_predictions[str(user_id)]['predictions'] = prediction_data['predictions']
                
                data_to_save["prediction_systems"][system_name] = {
                    "active": system_data['active'],
                    "auto_loop": system_data.get('auto_loop', False),
                    "predictions": serializable_predictions
                }
                
                # Save custom prediction data
                if system_name == 'custom':
                    data_to_save["prediction_systems"][system_name]["question"] = system_data.get('question', '')
                    data_to_save["prediction_systems"][system_name]["options"] = system_data.get('options', [])
                
                # Save timer information if active
                if system_name in TimerManager.active_timers:
                    timer_info = TimerManager.active_timers[system_name]
                    data_to_save["prediction_systems"][system_name]["timer_end_time"] = timer_info['end_time'].isoformat()
                    data_to_save["prediction_systems"][system_name]["timer_duration"] = timer_info['duration']
            
            # Write to file
            with open(PersistenceManager.DATA_FILE, 'w') as f:
                json.dump(data_to_save, f, indent=2)
                
        except Exception as e:
            print(f"Error saving data: {e}")
    
    @staticmethod
    async def load_data():
        """Load prediction data from file"""
        try:
            if not os.path.exists(PersistenceManager.DATA_FILE):
                print("No existing data file found, starting fresh")
                return
            
            with open(PersistenceManager.DATA_FILE, 'r') as f:
                data = json.load(f)
            
            from main import prediction_systems
            from timer_manager import TimerManager
            from statistics_manager import StatisticsManager
            
            # Load prediction systems
            if "prediction_systems" in data:
                for system_name, system_data in data["prediction_systems"].items():
                    if system_name in prediction_systems:
                        prediction_systems[system_name]['active'] = system_data.get('active', False)
                        prediction_systems[system_name]['auto_loop'] = system_data.get('auto_loop', False)
                        
                        # Load custom prediction data
                        if system_name == 'custom':
                            prediction_systems[system_name]['question'] = system_data.get('question', '')
                            prediction_systems[system_name]['options'] = system_data.get('options', [])
                        
                        # Restore predictions (but they'll be empty after restart due to user objects)
                        # In a real implementation, you'd need to restore user objects from user IDs
                        prediction_systems[system_name]['predictions'] = {}
            
            # Load custom durations
            if "custom_durations" in data:
                TimerManager.custom_durations = data["custom_durations"]
            
            # Load statistics
            if "statistics" in data:
                await StatisticsManager.load_persistent_data(data["statistics"])
            
            # Restore timers
            await TimerManager.restore_timers()
            
            print("Data loaded successfully")
            
        except Exception as e:
            print(f"Error loading data: {e}")
    
    @staticmethod
    async def backup_data():
        """Create a backup of current data"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_file = f"predictions_backup_{timestamp}.json"
            
            if os.path.exists(PersistenceManager.DATA_FILE):
                with open(PersistenceManager.DATA_FILE, 'r') as src:
                    with open(backup_file, 'w') as dst:
                        dst.write(src.read())
                
                print(f"Backup created: {backup_file}")
                
        except Exception as e:
            print(f"Error creating backup: {e}")
