import asyncio
import time
from datetime import datetime, timedelta
from typing import Dict

class ActivityMonitor:
    """Monitors chat activity and sends reminders during active predictions"""
    
    last_activity = {}  # channel_id -> timestamp
    reminder_tasks = {}  # system_name -> task
    bot_instance = None
    
    @staticmethod
    def start_monitoring(bot):
        """Initialize activity monitoring"""
        ActivityMonitor.bot_instance = bot
        asyncio.create_task(ActivityMonitor._activity_check_loop())
    
    @staticmethod
    def update_activity(channel_id: int):
        """Update last activity time for a channel"""
        ActivityMonitor.last_activity[channel_id] = time.time()
    
    @staticmethod
    async def start_reminder_monitoring(system_name: str, channel):
        """Start monitoring for a specific prediction system"""
        # Cancel existing reminder for this system
        if system_name in ActivityMonitor.reminder_tasks:
            ActivityMonitor.reminder_tasks[system_name].cancel()
        
        # Start new reminder task
        task = asyncio.create_task(
            ActivityMonitor._reminder_loop(system_name, channel)
        )
        ActivityMonitor.reminder_tasks[system_name] = task
    
    @staticmethod
    def stop_reminder_monitoring(system_name: str):
        """Stop monitoring for a specific prediction system"""
        if system_name in ActivityMonitor.reminder_tasks:
            ActivityMonitor.reminder_tasks[system_name].cancel()
            del ActivityMonitor.reminder_tasks[system_name]
    
    @staticmethod
    async def _reminder_loop(system_name: str, channel):
        """Send reminders every 2 minutes if no activity during active predictions"""
        try:
            from main import prediction_systems
            
            while prediction_systems[system_name]['active']:
                await asyncio.sleep(120)  # Check every 2 minutes
                
                # Check if predictions are still active
                if not prediction_systems[system_name]['active']:
                    break
                
                # Check last activity in this channel
                current_time = time.time()
                last_activity_time = ActivityMonitor.last_activity.get(channel.id, 0)
                
                # If no activity for 2 minutes, send reminder
                if current_time - last_activity_time >= 120:
                    await ActivityMonitor._send_reminder(system_name, channel)
                    
        except asyncio.CancelledError:
            pass  # Task was cancelled
        except Exception as e:
            print(f"Error in reminder loop for {system_name}: {e}")
    
    @staticmethod
    async def _send_reminder(system_name: str, channel):
        """Send activity reminder message"""
        from main import prediction_systems
        from timer_manager import TimerManager
        
        try:
            prediction_count = len(prediction_systems[system_name]['predictions'])
            time_remaining = TimerManager.get_time_remaining_formatted(system_name)
            
            if system_name == 'slotcall':
                # No timer for slot calls
                reminder_msg = f"🔔 **{system_name.upper()} REMINDER!** 🔔\n📝 **{prediction_count}** calls made so far!\nUse `!{system_name} YourKickUsername` to participate!"
            else:
                # Regular predictions with timer
                reminder_msg = f"🔔 **{system_name.upper()} REMINDER!** 🔔\n⏰ **{time_remaining}** remaining • **{prediction_count}** predictions made\nDon't forget to participate!"
            
            # Send reminder and update activity
            message = await channel.send(reminder_msg)
            ActivityMonitor.update_activity(channel.id)
            
            # Delete reminder after 15 seconds to avoid spam
            await asyncio.sleep(15)
            try:
                await message.delete()
            except:
                pass  # Message might already be deleted
                
        except Exception as e:
            print(f"Error sending reminder for {system_name}: {e}")
    
    @staticmethod
    async def _activity_check_loop():
        """Main activity monitoring loop"""
        while True:
            try:
                await asyncio.sleep(30)  # Check every 30 seconds
                # This loop can be used for additional activity monitoring features
                
            except Exception as e:
                print(f"Error in activity check loop: {e}")
