import asyncio
import discord
from datetime import datetime, timedelta
from typing import Dict, Optional

class ActivityMonitor:
    """Monitors channel activity and sends reminders for predictions"""
    
    bot_instance = None
    monitoring_tasks = {}  # system_name -> task
    last_activity = {}  # channel_id -> datetime
    reminder_intervals = {
        'first': 2,    # 2 minutes after opening
        'second': 1,   # 1 minute before closing (3 minutes after opening for 4-minute timer)
    }
    
    @staticmethod
    def start_monitoring(bot):
        """Initialize activity monitoring"""
        ActivityMonitor.bot_instance = bot
        print("Activity Monitor initialized")
    
    @staticmethod
    def update_activity(channel_id: int):
        """Update last activity time for a channel"""
        ActivityMonitor.last_activity[channel_id] = datetime.now()
    
    @staticmethod
    async def start_reminder_monitoring(system_name: str, channel):
        """Start monitoring for reminder messages"""
        # Cancel existing task
        ActivityMonitor.stop_reminder_monitoring(system_name)
        
        # Start new monitoring task
        task = asyncio.create_task(
            ActivityMonitor._reminder_task(system_name, channel)
        )
        ActivityMonitor.monitoring_tasks[system_name] = task
    
    @staticmethod
    def stop_reminder_monitoring(system_name: str):
        """Stop monitoring for a specific system"""
        if system_name in ActivityMonitor.monitoring_tasks:
            ActivityMonitor.monitoring_tasks[system_name].cancel()
            del ActivityMonitor.monitoring_tasks[system_name]
    
    @staticmethod
    async def _reminder_task(system_name: str, channel):
        """Internal task for sending reminders"""
        try:
            from timer_manager import TimerManager
            from main import prediction_systems
            
            # Get timer duration
            duration_minutes = TimerManager.get_custom_duration(system_name)
            
            # First reminder (2 minutes after opening)
            await asyncio.sleep(ActivityMonitor.reminder_intervals['first'] * 60)
            
            if prediction_systems[system_name]['active']:
                # Check if there's been recent activity
                if ActivityMonitor._should_send_reminder(channel.id):
                    command = ActivityMonitor._get_prediction_command(system_name)
                    embed = discord.Embed(
                        title=f"🔔 {system_name.upper()} Reminder",
                        description=f"Don't forget to make your prediction!\n\nUse `{command}` to participate!",
                        color=0xff9900
                    )
                    
                    remaining_time = TimerManager.get_time_remaining_formatted(system_name)
                    embed.add_field(name="⏰ Time Remaining", value=remaining_time, inline=True)
                    
                    await channel.send(embed=embed)
            
            # Second reminder (1 minute before closing)
            second_reminder_delay = (duration_minutes - 3) * 60  # For 4 min timer: 1 min delay
            if second_reminder_delay > 0:
                await asyncio.sleep(second_reminder_delay)
                
                if prediction_systems[system_name]['active']:
                    if ActivityMonitor._should_send_reminder(channel.id):
                        command = ActivityMonitor._get_prediction_command(system_name)
                        embed = discord.Embed(
                            title=f"⚠️ Last Call - {system_name.upper()}",
                            description=f"**Final reminder!** Predictions closing soon!\n\nUse `{command}` to participate!",
                            color=0xff0000
                        )
                        
                        remaining_time = TimerManager.get_time_remaining_formatted(system_name)
                        embed.add_field(name="⏰ Time Remaining", value=remaining_time, inline=True)
                        
                        await channel.send(embed=embed)
                        
        except asyncio.CancelledError:
            pass  # Task was cancelled
        except Exception as e:
            print(f"Error in reminder task for {system_name}: {e}")
    
    @staticmethod
    def _should_send_reminder(channel_id: int) -> bool:
        """Check if we should send a reminder based on recent activity"""
        if channel_id not in ActivityMonitor.last_activity:
            return True  # No recent activity, send reminder
        
        last_activity = ActivityMonitor.last_activity[channel_id]
        time_since_activity = datetime.now() - last_activity
        
        # Send reminder if no activity in last 30 seconds
        return time_since_activity > timedelta(seconds=30)
    
    @staticmethod
    def _get_prediction_command(system_name: str) -> str:
        """Get the prediction command for a system"""
        command_map = {
            'roulette': '!predict red/black/green/number YourKickUsername',
            'blackjack': '!predictbj win/lose YourKickUsername',
            'baccarat': '!predictbaccarat player/banker/tie YourKickUsername',
            'dice': '!predictdice number(s) YourKickUsername',
            'limbo': '!predictlimbo multiplier YourKickUsername',
            'marble': '!predictmarble number YourKickUsername',
            'custom': '!predictcustom option YourKickUsername',
            'slotcall': '!slotcall YourKickUsername'
        }
        return command_map.get(system_name, f'!predict{system_name} YourKickUsername')
