import discord
from discord.ext import commands
import random
import json
from datetime import datetime
from admin_utils import AdminUtils
from timer_manager import TimerManager
from activity_monitor import ActivityMonitor
from persistence_manager import PersistenceManager
from statistics_manager import StatisticsManager
from user_validator import UserValidator

class SlotCallCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def check_slotcall_winners(self, ctx, winner_username):
        from main import prediction_systems
        
        predictions = prediction_systems['slotcall']['predictions']
        kick_usernames_only = []
        all_participants = []
        total_players = len(predictions)

        for user_id, prediction_data in predictions.items():
            kick_username = prediction_data.get("kick_username", "Unknown")
            all_participants.append(kick_username)

        # Find the winner
        if winner_username.lower() in [username.lower() for username in all_participants]:
            # Find exact match (case insensitive)
            for username in all_participants:
                if username.lower() == winner_username.lower():
                    kick_usernames_only.append(username)
                    break

        # Send results
        if kick_usernames_only:
            winner_list = "\n".join(kick_usernames_only)
            copy_paste_box = f"```\n{winner_list}\n```"
            
            await ctx.send(f"🎉 **SLOT CALL WINNER!** 🎰\n{copy_paste_box}**{winner_username}** was called!\n\n📊 **1/{total_players}** players won!")
        else:
            await ctx.send(f"😔 **SLOT CALL MISS!** 😔\n**{winner_username}** was not in the participant list.\n📊 **Total participants:** {total_players}")

        # Record statistics
        await StatisticsManager.record_prediction_result('slotcall', kick_usernames_only, all_participants)

        # Clear predictions for next round
        prediction_systems['slotcall']['predictions'].clear()
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('slotcall')
        
        await PersistenceManager.save_data()

    @commands.command()
    async def slotcall(self, ctx, *, kick_username: str = ""):
        from main import prediction_systems
        
        # Check if wrong prediction system is being used
        error_msg = AdminUtils.check_wrong_prediction_command(ctx, 'slotcall')
        if error_msg and 'slotcall' not in AdminUtils.get_active_predictions():
            await ctx.send(error_msg)
            return

        if not prediction_systems['slotcall']['active']:
            await ctx.send("❌ Slot call is currently closed! Wait for an admin to open it.")
            return

        if not kick_username:
            await UserValidator.send_missing_username_notification(ctx)
            await ctx.send("❌ Please specify your kick username: `!slotcall YourKickUsername`")
            return

        # Validate kick username
        is_valid, error_msg = UserValidator.validate_kick_username(kick_username)
        if not is_valid:
            try:
                await ctx.author.send(f"**Invalid KickUsername Format**\n{error_msg}")
            except discord.Forbidden:
                pass
            await ctx.send("❌ Invalid KickUsername format! Check your DMs for details.")
            return

        # Check for username conflicts
        conflict_msg = await UserValidator.check_duplicate_username(kick_username, 'slotcall', ctx.author.id, ctx.author)
        if conflict_msg:
            try:
                await ctx.author.send(conflict_msg)
            except discord.Forbidden:
                pass
            await ctx.send("❌ Username conflict detected! Check your DMs.")
            return

        user_id = ctx.author.id
        predictions = prediction_systems['slotcall']['predictions']

        # Check if user already joined
        if user_id in predictions:
            old_username = predictions[user_id]["kick_username"]
            predictions[user_id] = {"user": ctx.author, "kick_username": kick_username}

            # Send DM confirmation
            try:
                await ctx.author.send(f"✅ **Slot Call Updated!**\nChanged from **{old_username}** to **{kick_username}**")
            except discord.Forbidden:
                pass  # User has DMs disabled

        else:
            # Register username
            await UserValidator.register_username(kick_username, 'slotcall', ctx.author.id, ctx.author)
            
            predictions[user_id] = {"user": ctx.author, "kick_username": kick_username}

            # Record user participation
            await StatisticsManager.record_user_participation(kick_username, ctx.author.id, 'slotcall')

            # Send DM confirmation
            try:
                await ctx.author.send(f"✅ **Slot Call Confirmed!**\nYou joined as **{kick_username}**")
            except discord.Forbidden:
                pass  # User has DMs disabled

        # Show current participant count and list of kick usernames
        total_participants = len(predictions)
        kick_usernames = [data["kick_username"] for data in predictions.values()]
        usernames_list = ", ".join(kick_usernames)

        await ctx.send(f"🎰 **{total_participants}** player(s) joined slot call!\n🎮 **Players:** {usernames_list}")
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def open_slotcall(self, ctx):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        prediction_systems['slotcall']['active'] = True
        # Clear previous round's participants when opening new round
        prediction_systems['slotcall']['predictions'].clear()
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('slotcall')
        
        # Start activity monitoring (no timer for slotcall)
        await ActivityMonitor.start_reminder_monitoring('slotcall', ctx.channel)
        
        message = await ctx.send(f"✅ **Slot Call is now OPEN!** 🎰\nUse `!slotcall YourKickUsername` to participate!\n⏰ **Manually closed by admin**")
        
        # Record statistics
        await StatisticsManager.record_prediction_opened('slotcall')
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def close_slotcall(self, ctx):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        prediction_systems['slotcall']['active'] = False
        prediction_count = len(prediction_systems['slotcall']['predictions'])
        
        # Stop activity monitoring (no timer to cancel)
        ActivityMonitor.stop_reminder_monitoring('slotcall')
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('slotcall')
        
        await ctx.send(f"🔒 **Slot Call is now CLOSED!** ({prediction_count} participants recorded)")
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def call_winner(self, ctx, *, winner_username: str = ""):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        if not winner_username:
            await ctx.send("❌ Please specify the winner: `!call_winner username`")
            return

        # Announce winner
        await ctx.send(f"🎰 **SLOT CALL RESULT:** **{winner_username}** 🔧")

        # Check for winners if participants exist
        from main import prediction_systems
        if prediction_systems['slotcall']['predictions']:
            await self.check_slotcall_winners(ctx, winner_username)

    @commands.command()
    async def random_call(self, ctx):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        
        if not prediction_systems['slotcall']['predictions']:
            await ctx.send("❌ No participants to call from!")
            return

        # Get all participants
        participants = [data["kick_username"] for data in prediction_systems['slotcall']['predictions'].values()]
        
        # Random selection
        winner = random.choice(participants)
        
        # Announce winner
        await ctx.send(f"🎰 **RANDOM SLOT CALL:** **{winner}** 🎲")

        # Process winner
        await self.check_slotcall_winners(ctx, winner)

async def setup(bot):
    await bot.add_cog(SlotCallCog(bot))
