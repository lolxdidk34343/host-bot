import discord
from discord.ext import commands
import random
import json
from datetime import datetime
from admin_utils import AdminUtils
from timer_manager import TimerManager
from activity_monitor import ActivityMonitor
from persistence_manager import PersistenceManager
from statistics_manager import StatisticsManager
from user_validator import UserValidator

class DiceCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def check_dice_prediction_winners(self, ctx, dice_result):
        from main import prediction_systems
        
        predictions = prediction_systems['dice']['predictions']
        winners = []
        kick_usernames_only = []
        all_participants = []
        total_players = len(predictions)
        total_predictions = 0

        for user_id, data in predictions.items():
            user = data["user"]
            user_predictions = data["predictions"]  # List of predictions
            kick_username = data["kick_username"]
            all_participants.append(kick_username)
            total_predictions += len(user_predictions)
            
            # Check if any prediction matches result (0-9)
            if str(dice_result) in [str(pred) for pred in user_predictions]:
                winners.append((user, kick_username))
                kick_usernames_only.append(kick_username)

        if winners:
            # Create copy-paste friendly winner announcement
            winner_list = "\n".join(kick_usernames_only)
            copy_paste_box = f"```\n{winner_list}\n```"
            
            await ctx.send(f"""🏆 **DICE PREDICTION WINNERS!** 🎲

{copy_paste_box}Correctly predicted **{dice_result}**!

📊 **{len(kick_usernames_only)}/{total_players}** players won!
📈 **Total predictions:** {total_predictions}""")
        else:
            await ctx.send(f"😔 **NO DICE WINNERS!** 😔\nNone of the **{total_players}** players predicted **{dice_result}** correctly.\n📈 **Total predictions:** {total_predictions}\nBetter luck next time!")

        # Record statistics
        await StatisticsManager.record_prediction_result('dice', kick_usernames_only, all_participants)

        # Clear predictions for next round
        prediction_systems['dice']['predictions'].clear()
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('dice')
        
        await PersistenceManager.save_data()

    @commands.command()
    async def dice(self, ctx):
        # Roll dice (0-9)
        dice_result = random.randint(0, 9)

        # Announce result
        await ctx.send(f"""🎲 **DICE RESULT** 🎲

🎯 **Result: {dice_result}**

*Random result*""")

        # Check for winners if predictions were made
        from main import prediction_systems
        if prediction_systems['dice']['predictions']:
            await self.check_dice_prediction_winners(ctx, dice_result)

    @commands.command()
    async def dice_manual(self, ctx, result: str = ""):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        if not result:
            await ctx.send("❌ Please specify the result: `!dice_manual 7`")
            return

        try:
            dice_result = int(result)
            if dice_result < 0 or dice_result > 9:
                raise ValueError()
        except ValueError:
            await ctx.send("❌ Result must be a number between 0-9")
            return

        # Send manual result
        await ctx.send(f"🎲 **Manual Dice Result:** **{dice_result}** 🔧")

        # Check for winners if predictions were made
        from main import prediction_systems
        if prediction_systems['dice']['predictions']:
            await self.check_dice_prediction_winners(ctx, dice_result)

    @commands.command()
    async def predictdice(self, ctx, predictions_str: str = "", *, kick_username: str = ""):
        from main import prediction_systems
        
        # Check if wrong prediction system is being used
        error_msg = AdminUtils.check_wrong_prediction_command(ctx, 'dice')
        if error_msg and 'dice' not in AdminUtils.get_active_predictions():
            await ctx.send(error_msg)
            return

        if not prediction_systems['dice']['active']:
            await ctx.send("❌ Dice predictions are currently closed! Wait for an admin to open them.")
            return

        if not predictions_str or not kick_username:
            await UserValidator.send_missing_username_notification(ctx)
            await ctx.send("❌ Please specify predictions and kick username: `!predictdice 1,5,7 YourKickUsername`")
            return

        # Validate kick username
        is_valid, error_msg = UserValidator.validate_kick_username(kick_username)
        if not is_valid:
            try:
                await ctx.author.send(f"**Invalid KickUsername Format**\n{error_msg}")
            except discord.Forbidden:
                pass
            await ctx.send("❌ Invalid KickUsername format! Check your DMs for details.")
            return

        # Check for username conflicts
        conflict_msg = await UserValidator.check_duplicate_username(kick_username, 'dice', ctx.author.id, ctx.author)
        if conflict_msg:
            try:
                await ctx.author.send(conflict_msg)
            except discord.Forbidden:
                pass
            await ctx.send("❌ Username conflict detected! Check your DMs.")
            return

        # Parse predictions (allow comma-separated or space-separated)
        predictions_str = predictions_str.replace(',', ' ')
        prediction_parts = predictions_str.split()
        
        predictions = []
        for part in prediction_parts:
            try:
                num = int(part)
                if 0 <= num <= 9:
                    predictions.append(num)
                else:
                    await ctx.send(f"❌ Invalid number: **{num}**. Must be between 0-9")
                    return
            except ValueError:
                await ctx.send(f"❌ Invalid prediction: **{part}**. Must be numbers between 0-9")
                return

        if not predictions:
            await ctx.send("❌ No valid predictions found! Please provide numbers between 0-9")
            return

        if len(predictions) > 5:
            await ctx.send("❌ Too many predictions! Maximum 5 numbers allowed")
            return

        # Remove duplicates while preserving order
        unique_predictions = []
        for pred in predictions:
            if pred not in unique_predictions:
                unique_predictions.append(pred)
        predictions = unique_predictions

        user_id = ctx.author.id
        system_predictions = prediction_systems['dice']['predictions']

        # Check if user already made a prediction
        if user_id in system_predictions:
            old_predictions = system_predictions[user_id]["predictions"]
            system_predictions[user_id] = {"predictions": predictions, "user": ctx.author, "kick_username": kick_username}

            # Send DM confirmation
            try:
                old_list = ", ".join(map(str, old_predictions))
                new_list = ", ".join(map(str, predictions))
                await ctx.author.send(f"✅ **Dice Prediction Updated!**\nChanged from **{old_list}** to **{new_list}**")
            except discord.Forbidden:
                pass  # User has DMs disabled

        else:
            # Register username
            await UserValidator.register_username(kick_username, 'dice', ctx.author.id, ctx.author)
            
            system_predictions[user_id] = {"predictions": predictions, "user": ctx.author, "kick_username": kick_username}

            # Record user participation
            await StatisticsManager.record_user_participation(kick_username, ctx.author.id, 'dice')

            # Send DM confirmation
            try:
                pred_list = ", ".join(map(str, predictions))
                await ctx.author.send(f"✅ **Dice Prediction Confirmed!**\nYou predicted **{pred_list}**")
            except discord.Forbidden:
                pass  # User has DMs disabled

        # Show current prediction count and list of kick usernames
        total_predictions = len(system_predictions)
        kick_usernames = [data["kick_username"] for data in system_predictions.values()]
        usernames_list = ", ".join(kick_usernames)

        pred_display = ", ".join(map(str, predictions))
        await ctx.send(f"🎲 **{total_predictions}** player(s) have made dice predictions!\n🎮 **Players:** {usernames_list}\n🎯 **Your predictions:** {pred_display}")
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def open_dice_predictions(self, ctx):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        prediction_systems['dice']['active'] = True
        # Clear previous round's predictions when opening new round
        prediction_systems['dice']['predictions'].clear()
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('dice')
        
        # Get custom duration
        duration_minutes = TimerManager.get_custom_duration('dice')
        
        # Start timer
        await TimerManager.start_prediction_timer('dice', ctx, duration_minutes=duration_minutes)
        
        # Start activity monitoring
        await ActivityMonitor.start_reminder_monitoring('dice', ctx.channel)
        
        timestamp_str = TimerManager.get_discord_timestamp('dice') or f"in {duration_minutes} minutes"
        message = await ctx.send(f"✅ **Dice predictions are now OPEN!** 🎲\nUse `!predictdice 1,5,7 YourKickUsername` to participate!\n⏰ **Auto-closes {timestamp_str}**")
        
        # Delete this message when predictions close
        await AdminUtils.schedule_message_deletion(message, 'dice')
        
        # Record statistics
        await StatisticsManager.record_prediction_opened('dice')
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def close_dice_predictions(self, ctx):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        prediction_systems['dice']['active'] = False
        prediction_count = len(prediction_systems['dice']['predictions'])
        
        # Cancel timer and stop activity monitoring
        TimerManager.cancel_timer('dice')
        ActivityMonitor.stop_reminder_monitoring('dice')
        
        # Delete pending messages
        await AdminUtils.delete_pending_messages('dice')
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('dice')
        
        await ctx.send(f"🔒 **Dice predictions are now CLOSED!** ({prediction_count} predictions recorded)")
        
        # Save data
        await PersistenceManager.save_data()

async def setup(bot):
    await bot.add_cog(DiceCog(bot))
