import discord
from discord.ext import commands
from typing import List, Dict, Optional
import asyncio

class AdminUtils:
    """Utility functions for admin operations"""
    
    # Admin role names that can use admin commands
    ADMIN_ROLES = ["Admin", "Moderator", "Owner", "admin", "moderator", "owner"]
    
    # Store messages to delete when predictions close
    pending_deletions = {}  # system_name -> [messages]
    
    @staticmethod
    def has_admin_role(user) -> bool:
        """Check if user has admin role"""
        if not hasattr(user, 'roles'):
            return False
        
        user_roles = [role.name for role in user.roles]
        return any(role in AdminUtils.ADMIN_ROLES for role in user_roles)
    
    @staticmethod
    async def check_admin_permission(ctx) -> bool:
        """Check admin permission and send error if not admin"""
        if not AdminUtils.has_admin_role(ctx.author):
            await ctx.send("❌ You don't have permission to use this command!")
            return False
        return True
    
    @staticmethod
    def check_wrong_prediction_command(ctx, system_name: str) -> Optional[str]:
        """Check if user is using wrong prediction command for active system"""
        from main import prediction_systems
        
        # Find active prediction systems
        active_systems = [name for name, data in prediction_systems.items() if data['active']]
        
        if active_systems and system_name not in active_systems:
            active_system = active_systems[0]  # Get first active system
            correct_command = AdminUtils.get_prediction_command(active_system)
            return f"❌ Wrong prediction system! **{active_system.upper()}** predictions are currently open. Use `{correct_command}` instead!"
        
        return None
    
    @staticmethod
    def get_prediction_command(system_name: str) -> str:
        """Get the prediction command for a system"""
        command_map = {
            'roulette': '!predict',
            'blackjack': '!predictbj',
            'baccarat': '!predictbaccarat',
            'dice': '!predictdice',
            'limbo': '!predictlimbo',
            'marble': '!predictmarble',
            'custom': '!predictcustom',
            'slotcall': '!slotcall'
        }
        return command_map.get(system_name, f'!predict{system_name}')
    
    @staticmethod
    def get_active_predictions() -> List[str]:
        """Get list of currently active prediction systems"""
        from main import prediction_systems
        return [name for name, data in prediction_systems.items() if data['active']]
    
    @staticmethod
    async def schedule_message_deletion(message, system_name: str):
        """Schedule a message for deletion when predictions close"""
        if system_name not in AdminUtils.pending_deletions:
            AdminUtils.pending_deletions[system_name] = []
        AdminUtils.pending_deletions[system_name].append(message)
    
    @staticmethod
    async def delete_pending_messages(system_name: str):
        """Delete all pending messages for a system"""
        if system_name not in AdminUtils.pending_deletions:
            return
        
        for message in AdminUtils.pending_deletions[system_name]:
            try:
                await message.delete()
            except discord.NotFound:
                pass  # Message already deleted
            except discord.Forbidden:
                pass  # No permission to delete
            except Exception as e:
                print(f"Error deleting message: {e}")
        
        # Clear the list
        AdminUtils.pending_deletions[system_name] = []

def setup_admin_commands(bot):
    """Set up admin commands"""
    
    @bot.command()
    async def stats(ctx):
        """View prediction statistics (Admin only)"""
        if not await AdminUtils.check_admin_permission(ctx):
            return
        
        from statistics_manager import StatisticsManager
        stats = await StatisticsManager.get_overall_statistics()
        
        embed = discord.Embed(
            title="📊 Prediction Bot Statistics",
            color=0x00ff00
        )
        
        embed.add_field(
            name="📈 Overall Stats",
            value=f"""
            **Total Predictions Opened:** {stats['total_predictions_opened']}
            **Total Users Joined:** {stats['total_users_joined']}
            **Total Winners:** {stats['total_users_won']}
            **Total Losers:** {stats['total_users_lost']}
            """,
            inline=False
        )
        
        if stats['top_winner']:
            embed.add_field(
                name="🏆 Top Winner",
                value=f"**{stats['top_winner']['username']}** - {stats['top_winner']['wins']} wins",
                inline=False
            )
        
        await ctx.send(embed=embed)
    
    @bot.command()
    async def close_all_predictions(ctx):
        """Close all active predictions (Admin only)"""
        if not await AdminUtils.check_admin_permission(ctx):
            return
        
        from main import prediction_systems
        from timer_manager import TimerManager
        from activity_monitor import ActivityMonitor
        from user_validator import UserValidator
        from persistence_manager import PersistenceManager
        
        closed_systems = []
        
        for system_name, system_data in prediction_systems.items():
            if system_data['active']:
                system_data['active'] = False
                closed_systems.append(system_name.upper())
                
                # Cancel timer and stop monitoring
                TimerManager.cancel_timer(system_name)
                ActivityMonitor.stop_reminder_monitoring(system_name)
                
                # Delete pending messages
                await AdminUtils.delete_pending_messages(system_name)
                
                # Clear usernames
                await UserValidator.clear_system_usernames(system_name)
        
        if closed_systems:
            await ctx.send(f"🔒 **Closed all active predictions:** {', '.join(closed_systems)}")
        else:
            await ctx.send("❌ No active predictions to close!")
        
        # Save data
        await PersistenceManager.save_data()
