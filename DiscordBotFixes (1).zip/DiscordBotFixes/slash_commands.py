import discord
from discord.ext import commands
from discord import app_commands
from admin_utils import AdminUtils
from timer_manager import TimerManager
from statistics_manager import StatisticsManager
from user_validator import UserValidator

class SlashCommands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="set_timer", description="Set custom prediction timer duration (Admin only)")
    @app_commands.describe(
        system="Prediction system name",
        minutes="Duration in minutes (1-60)"
    )
    @app_commands.choices(system=[
        app_commands.Choice(name="Roulette", value="roulette"),
        app_commands.Choice(name="Blackjack", value="blackjack"),
        app_commands.Choice(name="Baccarat", value="baccarat"),
        app_commands.Choice(name="Dice", value="dice"),
        app_commands.Choice(name="Limbo", value="limbo"),
        app_commands.Choice(name="Marble", value="marble"),
        app_commands.Choice(name="Custom", value="custom"),
    ])
    async def set_timer(self, interaction: discord.Interaction, system: str, minutes: int):
        """Set custom timer duration for a prediction system"""
        if not AdminUtils.has_admin_role(interaction.user):
            await interaction.response.send_message("❌ You don't have permission to use this command!", ephemeral=True)
            return
        
        if minutes < 1 or minutes > 60:
            await interaction.response.send_message("❌ Timer must be between 1-60 minutes!", ephemeral=True)
            return
        
        TimerManager.set_custom_duration(system, minutes)
        
        await interaction.response.send_message(
            f"✅ **Timer Updated!**\n"
            f"**{system.upper()}** predictions will now run for **{minutes} minutes** instead of the default 4 minutes.",
            ephemeral=False
        )
        
        # Save data
        from persistence_manager import PersistenceManager
        await PersistenceManager.save_data()

    @app_commands.command(name="manual_result", description="Override prediction result manually (Admin only)")
    @app_commands.describe(
        system="Prediction system name",
        result="The result to set"
    )
    @app_commands.choices(system=[
        app_commands.Choice(name="Roulette", value="roulette"),
        app_commands.Choice(name="Blackjack", value="blackjack"),
        app_commands.Choice(name="Baccarat", value="baccarat"),
        app_commands.Choice(name="Dice", value="dice"),
        app_commands.Choice(name="Limbo", value="limbo"),
        app_commands.Choice(name="Marble", value="marble"),
        app_commands.Choice(name="Custom", value="custom"),
    ])
    async def manual_result(self, interaction: discord.Interaction, system: str, result: str):
        """Manually set the result for a prediction system"""
        if not AdminUtils.has_admin_role(interaction.user):
            await interaction.response.send_message("❌ You don't have permission to use this command!", ephemeral=True)
            return
        
        from main import prediction_systems
        
        # Check if there are predictions to resolve
        if not prediction_systems[system]['predictions']:
            await interaction.response.send_message(f"❌ No active predictions for {system.upper()}!", ephemeral=True)
            return
        
        # Validate result based on system type
        valid_results = {
            'roulette': ['red', 'black', 'green'] + [str(i) for i in range(37)],
            'blackjack': ['win', 'lose'],
            'baccarat': ['player', 'banker', 'tie'],
            'dice': [str(i) for i in range(10)],
            'limbo': [str(i) for i in range(1, 21)],  # Assuming 1-20 range
            'marble': ['RED', 'BLUE', 'YELLOW', 'WHITE', 'BLACK', 'GREEN'],
            'custom': prediction_systems['custom'].get('options', [])
        }
        
        if system in valid_results and result not in valid_results[system]:
            await interaction.response.send_message(
                f"❌ Invalid result for {system.upper()}! Valid options: {', '.join(valid_results[system][:10])}{'...' if len(valid_results[system]) > 10 else ''}",
                ephemeral=True
            )
            return
        
        # Send manual result to the channel
        await interaction.response.send_message(f"🔧 **Manual {system.upper()} Result:** **{result}** 🔧")
        
        # Process winners based on system type
        await self._process_manual_result(interaction, system, result)

    async def _process_manual_result(self, interaction: discord.Interaction, system: str, result: str):
        """Process manual result and determine winners"""
        from main import prediction_systems
        
        try:
            # Import the appropriate command handler
            if system == 'roulette':
                from roulette_commands import RouletteCog
                cog = self.bot.get_cog('RouletteCog')
                if cog:
                    if result.isdigit():
                        await cog.check_roulette_prediction_winners(interaction, int(result))
                    else:
                        # For color predictions, we need to simulate a number
                        color_numbers = {
                            'red': 1,  # Any red number
                            'black': 2,  # Any black number
                            'green': 0  # Green number
                        }
                        await cog.check_roulette_prediction_winners(interaction, color_numbers.get(result, 0))
                    
            elif system == 'blackjack':
                from blackjack_commands import BlackjackCog
                cog = self.bot.get_cog('BlackjackCog')
                if cog:
                    winner = "player" if result == "win" else "dealer"
                    await cog.check_blackjack_prediction_winners(interaction, winner)
                    
            elif system == 'baccarat':
                from baccarat_commands import BaccaratCog
                cog = self.bot.get_cog('BaccaratCog')
                if cog:
                    await cog.check_baccarat_prediction_winners(interaction, result)
                    
            elif system == 'dice':
                from dice_commands import DiceCog
                cog = self.bot.get_cog('DiceCog')
                if cog:
                    await cog.check_dice_prediction_winners(interaction, int(result))
                    
            elif system == 'limbo':
                from limbo_commands import LimboCog
                cog = self.bot.get_cog('LimboCog')
                if cog:
                    await cog.check_limbo_prediction_winners(interaction, float(result))
                    
            elif system == 'marble':
                from marble_commands import MarbleCog
                cog = self.bot.get_cog('MarbleCog')
                if cog:
                    await cog.check_marble_prediction_winners(interaction, int(result))
                    
            elif system == 'custom':
                from custom_predictions import CustomPredictionCog
                cog = self.bot.get_cog('CustomPredictionCog')
                if cog:
                    await cog.check_custom_prediction_winners(interaction, result)
                    
        except Exception as e:
            await interaction.followup.send(f"❌ Error processing manual result: {str(e)}", ephemeral=True)

    @app_commands.command(name="open_predictions", description="Open predictions for a system (Admin only)")
    @app_commands.describe(
        system="Prediction system to open",
        duration="Duration in minutes (optional, uses custom setting or default 4)"
    )
    @app_commands.choices(system=[
        app_commands.Choice(name="Roulette", value="roulette"),
        app_commands.Choice(name="Blackjack", value="blackjack"),
        app_commands.Choice(name="Baccarat", value="baccarat"),
        app_commands.Choice(name="Dice", value="dice"),
        app_commands.Choice(name="Limbo", value="limbo"),
        app_commands.Choice(name="Marble", value="marble"),
        app_commands.Choice(name="Custom", value="custom"),
        app_commands.Choice(name="Slot Call", value="slotcall"),
    ])
    async def open_predictions(self, interaction: discord.Interaction, system: str, duration: int = 0):
        """Open predictions for a specific system"""
        if not AdminUtils.has_admin_role(interaction.user):
            await interaction.response.send_message("❌ You don't have permission to use this command!", ephemeral=True)
            return
        
        if duration and (duration < 1 or duration > 60):
            await interaction.response.send_message("❌ Duration must be between 1-60 minutes!", ephemeral=True)
            return
        
        from main import prediction_systems
        from activity_monitor import ActivityMonitor
        
        # Check if already active
        if prediction_systems[system]['active']:
            await interaction.response.send_message(f"❌ {system.upper()} predictions are already open!", ephemeral=True)
            return
        
        # Open predictions
        prediction_systems[system]['active'] = True
        prediction_systems[system]['predictions'].clear()
        
        # Set custom duration if provided
        if duration:
            TimerManager.set_custom_duration(system, duration)
        
        # Get effective duration
        effective_duration = duration or TimerManager.get_custom_duration(system)
        
        # Start timer (except for slotcall)
        if system != 'slotcall':
            await TimerManager.start_prediction_timer(system, interaction, duration_minutes=effective_duration)
        
        # Start activity monitoring
        await ActivityMonitor.start_reminder_monitoring(system, interaction.channel)
        
        # Create response message with proper command instructions
        command_instructions = {
            'roulette': '`!predict red/black/green/number YourKickUsername`',
            'blackjack': '`!predictbj win/lose YourKickUsername`',
            'baccarat': '`!predictbaccarat player/banker/tie YourKickUsername`',
            'dice': '`!predictdice 1,5,7 YourKickUsername`',
            'limbo': '`!predictlimbo 5.5 YourKickUsername`',
            'marble': '`!predictmarble RED YourKickUsername` (2 guesses: RED, BLUE, YELLOW, WHITE, BLACK, GREEN)',
            'custom': '`!predictcustom answer YourKickUsername`',
            'slotcall': '`!slotcall YourKickUsername`'
        }
        
        command_text = command_instructions.get(system, f'`!predict{system} YourKickUsername`')
        
        if system == 'slotcall':
            message_text = f"✅ **{system.upper()} is now OPEN!** 📢\nUse {command_text} to participate!"
        else:
            timestamp_str = TimerManager.get_discord_timestamp(system) or f"in {effective_duration} minutes"
            message_text = f"✅ **{system.upper()} predictions are now OPEN!** 🎲\nUse {command_text} to participate!\n⏰ **Auto-closes {timestamp_str}**"
        
        await interaction.response.send_message(message_text)
        
        # Record statistics
        await StatisticsManager.record_prediction_opened(system)
        
        # Save data
        from persistence_manager import PersistenceManager
        await PersistenceManager.save_data()

    @app_commands.command(name="close_predictions", description="Close predictions for a system (Admin only)")
    @app_commands.describe(system="Prediction system to close")
    @app_commands.choices(system=[
        app_commands.Choice(name="Roulette", value="roulette"),
        app_commands.Choice(name="Blackjack", value="blackjack"),
        app_commands.Choice(name="Baccarat", value="baccarat"),
        app_commands.Choice(name="Dice", value="dice"),
        app_commands.Choice(name="Limbo", value="limbo"),
        app_commands.Choice(name="Marble", value="marble"),
        app_commands.Choice(name="Custom", value="custom"),
        app_commands.Choice(name="Slot Call", value="slotcall"),
    ])
    async def close_predictions(self, interaction: discord.Interaction, system: str):
        """Close predictions for a specific system"""
        if not AdminUtils.has_admin_role(interaction.user):
            await interaction.response.send_message("❌ You don't have permission to use this command!", ephemeral=True)
            return
        
        from main import prediction_systems
        from activity_monitor import ActivityMonitor
        
        if not prediction_systems[system]['active']:
            await interaction.response.send_message(f"❌ {system.upper()} predictions are not currently open!", ephemeral=True)
            return
        
        # Close predictions
        prediction_systems[system]['active'] = False
        prediction_count = len(prediction_systems[system]['predictions'])
        
        # Cancel timer and stop activity monitoring
        TimerManager.cancel_timer(system)
        ActivityMonitor.stop_reminder_monitoring(system)
        
        # Delete pending messages
        await AdminUtils.delete_pending_messages(system)
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames(system)
        
        await interaction.response.send_message(f"🔒 **{system.upper()} predictions are now CLOSED!** ({prediction_count} predictions recorded)")
        
        # Save data
        from persistence_manager import PersistenceManager
        await PersistenceManager.save_data()

async def setup(bot):
    await bot.add_cog(SlashCommands(bot))
