import discord
from discord.ext import commands
import random
import json
from datetime import datetime
from admin_utils import AdminUtils
from timer_manager import TimerManager
from activity_monitor import ActivityMonitor
from persistence_manager import PersistenceManager
from statistics_manager import StatisticsManager
from user_validator import UserValidator

class RouletteCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def check_roulette_prediction_winners(self, ctx, result):
        from main import prediction_systems
        
        predictions = prediction_systems['roulette']['predictions']
        winners = []
        kick_usernames_only = []
        all_participants = []
        total_players = len(predictions)

        # Determine color based on number
        if result == 0:
            color = "green"
        elif result in [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]:
            color = "red"
        else:
            color = "black"

        for user_id, prediction_data in predictions.items():
            user_prediction = prediction_data["prediction"]
            user = prediction_data["user"]
            kick_username = prediction_data.get("kick_username", "Unknown")
            all_participants.append(kick_username)

            # Check if prediction matches
            won = False
            if user_prediction.lower() == color:
                won = True
            elif user_prediction.isdigit() and int(user_prediction) == result:
                won = True

            if won:
                kick_usernames_only.append(kick_username)

        # Send results
        if kick_usernames_only:
            winner_list = "\n".join(kick_usernames_only)
            copy_paste_box = f"```\n{winner_list}\n```"
            
            await ctx.send(f"🎉 **ROULETTE PREDICTION WINNERS!** 🎉\n{copy_paste_box}Correctly predicted **{result} ({color.upper()})**!\n\n📊 **{len(kick_usernames_only)}/{total_players}** players won!")
        else:
            await ctx.send(f"😔 **NO ROULETTE WINNERS!** 😔\nNone of the **{total_players}** players predicted **{result} ({color.upper()})** correctly.\nBetter luck next time!")

        # Record statistics
        await StatisticsManager.record_prediction_result('roulette', kick_usernames_only, all_participants)

        # Clear predictions for next round
        prediction_systems['roulette']['predictions'].clear()
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('roulette')
        
        await PersistenceManager.save_data()

    @commands.command()
    async def roulette(self, ctx):
        # Roll roulette (0-36)
        roulette_result = random.randint(0, 36)

        # Determine color
        if roulette_result == 0:
            color = "🟢 GREEN"
        elif roulette_result in [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]:
            color = "🔴 RED"
        else:
            color = "⚫ BLACK"

        # Announce result
        await ctx.send(f"""🎰 **ROULETTE RESULT** 🎰

🎯 **{roulette_result}** {color}

*Random result*""")

        # Check for winners if predictions were made
        from main import prediction_systems
        if prediction_systems['roulette']['predictions']:
            await self.check_roulette_prediction_winners(ctx, roulette_result)

    @commands.command()
    async def roulette_manual(self, ctx, result: str = ""):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        if not result:
            await ctx.send("❌ Please specify the result: `!roulette_manual 17`")
            return

        try:
            roulette_result = int(result)
            if roulette_result < 0 or roulette_result > 36:
                raise ValueError()
        except ValueError:
            await ctx.send("❌ Result must be a number between 0-36")
            return

        # Determine color
        if roulette_result == 0:
            color = "🟢 GREEN"
        elif roulette_result in [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]:
            color = "🔴 RED"
        else:
            color = "⚫ BLACK"

        # Send manual result
        await ctx.send(f"🎰 **Manual Roulette Result:** **{roulette_result}** {color} 🔧")

        # Check for winners if predictions were made
        from main import prediction_systems
        if prediction_systems['roulette']['predictions']:
            await self.check_roulette_prediction_winners(ctx, roulette_result)

    @commands.command()
    async def predict(self, ctx, prediction: str = "", *, kick_username: str = ""):
        from main import prediction_systems
        
        # Check if wrong prediction system is being used
        error_msg = AdminUtils.check_wrong_prediction_command(ctx, 'roulette')
        if error_msg and 'roulette' not in AdminUtils.get_active_predictions():
            await ctx.send(error_msg)
            return

        if not prediction_systems['roulette']['active']:
            await ctx.send("❌ Roulette predictions are currently closed! Wait for an admin to open them.")
            return

        if not prediction or not kick_username:
            await UserValidator.send_missing_username_notification(ctx)
            await ctx.send("❌ Please specify both prediction and kick username: `!predict red YourKickUsername`")
            return

        # Validate kick username
        is_valid, error_msg = UserValidator.validate_kick_username(kick_username)
        if not is_valid:
            try:
                await ctx.author.send(f"**Invalid KickUsername Format**\n{error_msg}")
            except discord.Forbidden:
                pass
            await ctx.send("❌ Invalid KickUsername format! Check your DMs for details.")
            return

        # Check for username conflicts
        conflict_msg = await UserValidator.check_duplicate_username(kick_username, 'roulette', ctx.author.id, ctx.author)
        if conflict_msg:
            try:
                await ctx.author.send(conflict_msg)
            except discord.Forbidden:
                pass
            await ctx.send("❌ Username conflict detected! Check your DMs.")
            return

        # Validate prediction
        prediction = prediction.lower()
        valid_colors = ["red", "black", "green"]
        valid_numbers = [str(i) for i in range(37)]
        
        if prediction not in valid_colors and prediction not in valid_numbers:
            await ctx.send("❌ Invalid prediction! Please choose: **red**, **black**, **green**, or a number (0-36)")
            return

        user_id = ctx.author.id
        predictions = prediction_systems['roulette']['predictions']

        # Check if user already made a prediction
        if user_id in predictions:
            old_prediction = predictions[user_id]["prediction"]
            predictions[user_id] = {"prediction": prediction, "user": ctx.author, "kick_username": kick_username}

            # Send DM confirmation
            try:
                await ctx.author.send(f"✅ **Roulette Prediction Updated!**\nChanged from **{old_prediction.upper()}** to **{prediction.upper()}**")
            except discord.Forbidden:
                pass  # User has DMs disabled

        else:
            # Register username
            await UserValidator.register_username(kick_username, 'roulette', ctx.author.id, ctx.author)
            
            predictions[user_id] = {"prediction": prediction, "user": ctx.author, "kick_username": kick_username}

            # Record user participation
            await StatisticsManager.record_user_participation(kick_username, ctx.author.id, 'roulette')

            # Send DM confirmation
            try:
                await ctx.author.send(f"✅ **Roulette Prediction Confirmed!**\nYou predicted **{prediction.upper()}**")
            except discord.Forbidden:
                pass  # User has DMs disabled

        # Show current prediction count and list of kick usernames
        total_predictions = len(predictions)
        kick_usernames = [data["kick_username"] for data in predictions.values()]
        usernames_list = ", ".join(kick_usernames)

        await ctx.send(f"🎰 **{total_predictions}** player(s) have made roulette predictions!\n🎮 **Players:** {usernames_list}")
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def open_roulette_predictions(self, ctx):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        prediction_systems['roulette']['active'] = True
        # Clear previous round's predictions when opening new round
        prediction_systems['roulette']['predictions'].clear()
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('roulette')
        
        # Get custom duration
        duration_minutes = TimerManager.get_custom_duration('roulette')
        
        # Start timer
        await TimerManager.start_prediction_timer('roulette', ctx, duration_minutes=duration_minutes)
        
        # Start activity monitoring
        await ActivityMonitor.start_reminder_monitoring('roulette', ctx.channel)
        
        timestamp_str = TimerManager.get_discord_timestamp('roulette') or f"in {duration_minutes} minutes"
        message = await ctx.send(f"✅ **Roulette predictions are now OPEN!** 🎰\nUse `!predict red/black/green/number YourKickUsername` to participate!\n⏰ **Auto-closes {timestamp_str}**")
        
        # Delete this message when predictions close
        await AdminUtils.schedule_message_deletion(message, 'roulette')
        
        # Record statistics
        await StatisticsManager.record_prediction_opened('roulette')
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def close_roulette_predictions(self, ctx):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        prediction_systems['roulette']['active'] = False
        prediction_count = len(prediction_systems['roulette']['predictions'])
        
        # Cancel timer and stop activity monitoring
        TimerManager.cancel_timer('roulette')
        ActivityMonitor.stop_reminder_monitoring('roulette')
        
        # Delete pending messages
        await AdminUtils.delete_pending_messages('roulette')
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('roulette')
        
        await ctx.send(f"🔒 **Roulette predictions are now CLOSED!** ({prediction_count} predictions recorded)")
        
        # Save data
        await PersistenceManager.save_data()

async def setup(bot):
    await bot.add_cog(RouletteCog(bot))
