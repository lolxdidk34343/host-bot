import discord
from discord.ext import commands
import random
import json
from datetime import datetime
import asyncio
from admin_utils import AdminUtils
from timer_manager import TimerManager
from activity_monitor import ActivityMonitor
from persistence_manager import PersistenceManager
from statistics_manager import StatisticsManager
from user_validator import UserValidator

class BaccaratCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.trivia_active = False
        self.trivia_answer = None
        self.trivia_channel = None

    async def check_baccarat_prediction_winners(self, ctx, winner):
        from main import prediction_systems
        
        predictions = prediction_systems['baccarat']['predictions']
        winners = []
        kick_usernames_only = []
        all_participants = []
        total_players = len(predictions)

        # Convert game result to prediction format
        result = winner.lower()  # player, banker, or tie

        for user_id, prediction_data in predictions.items():
            user_prediction = prediction_data["prediction"]
            user = prediction_data["user"]
            kick_username = prediction_data.get("kick_username", "Unknown")
            all_participants.append(kick_username)

            # Check if prediction matches
            won = False
            if user_prediction == result:
                won = True

            if won:
                kick_usernames_only.append(kick_username)

        # Send results in friendly copy-paste box format
        if kick_usernames_only:
            winner_list = "\n".join(kick_usernames_only)
            copy_paste_box = f"```\n{winner_list}\n```"
            
            await ctx.send(f"🎉 **BACCARAT PREDICTION WINNERS!** 🎉\n{copy_paste_box}Correctly predicted **{result.upper()}**!\n\n📊 **{len(kick_usernames_only)}/{total_players}** players won!")
        else:
            await ctx.send(f"😔 **NO BACCARAT WINNERS!** 😔\nNone of the **{total_players}** players predicted **{result.upper()}** correctly.\nBetter luck next time!")

        # Record statistics
        await StatisticsManager.record_prediction_result('baccarat', kick_usernames_only, all_participants)

        # Clear predictions for next round
        prediction_systems['baccarat']['predictions'].clear()
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('baccarat')
        
        await PersistenceManager.save_data()

    @commands.command()
    async def baccarat(self, ctx):
        # Randomly determine result
        random_result = random.choice(["player", "banker", "tie"])

        # Simple result announcement
        if random_result == "player":
            result_text = "🏆 **PLAYER WINS!**"
            result_emoji = "👤"
        elif random_result == "banker":
            result_text = "🏦 **BANKER WINS!**"
            result_emoji = "🏦"
        else:  # tie
            result_text = "🤝 **TIE!**"
            result_emoji = "🤝"

        # Announce result
        await ctx.send(f"""🎴 **BACCARAT RESULT** 🎴

{result_text}

{result_emoji} **{random_result.upper()}** {result_emoji}

*Random result*""")

        # Check for winners if predictions were made
        from main import prediction_systems
        if prediction_systems['baccarat']['predictions']:
            await self.check_baccarat_prediction_winners(ctx, random_result)

    @commands.command()
    async def baccarat_manual(self, ctx, custom_result: str = None):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        if custom_result is None:
            await ctx.send("❌ Please specify the result: `!baccarat_manual player/banker/tie`")
            return

        custom_result = custom_result.lower()
        if custom_result not in ["player", "banker", "tie"]:
            await ctx.send("❌ Result must be: **player**, **banker**, or **tie**")
            return

        # Simple result announcement
        if custom_result == "player":
            result_text = "🏆 **PLAYER WINS!**"
            result_emoji = "👤"
        elif custom_result == "banker":
            result_text = "🏦 **BANKER WINS!**"
            result_emoji = "🏦"
        else:  # tie
            result_text = "🤝 **TIE!**"
            result_emoji = "🤝"

        # Send manual result
        await ctx.send(f"🎴 **Manual Result:** {result_text} {result_emoji} **{custom_result.upper()}** 🔧")

        # Check for winners if predictions were made
        from main import prediction_systems
        if prediction_systems['baccarat']['predictions']:
            await self.check_baccarat_prediction_winners(ctx, custom_result)

    @commands.command()
    async def predictbaccarat(self, ctx, prediction: str = None, *, kick_username: str = None):
        from main import prediction_systems
        
        # Check if wrong prediction system is being used
        error_msg = AdminUtils.check_wrong_prediction_command(ctx, 'baccarat')
        if error_msg and 'baccarat' not in AdminUtils.get_active_predictions():
            await ctx.send(error_msg)
            return

        if not prediction_systems['baccarat']['active']:
            await ctx.send("❌ Baccarat predictions are currently closed! Wait for an admin to open them.")
            return

        if not prediction or not kick_username:
            await UserValidator.send_missing_username_notification(ctx)
            await ctx.send("❌ Please specify both prediction and kick username: `!predictbaccarat player YourKickUsername`")
            return

        # Validate kick username
        is_valid, error_msg = UserValidator.validate_kick_username(kick_username)
        if not is_valid:
            try:
                await ctx.author.send(f"**Invalid KickUsername Format**\n{error_msg}")
            except discord.Forbidden:
                pass
            await ctx.send("❌ Invalid KickUsername format! Check your DMs for details.")
            return

        # Check for username conflicts
        conflict_msg = await UserValidator.check_duplicate_username(kick_username, 'baccarat', ctx.author.id, ctx.author)
        if conflict_msg:
            try:
                await ctx.author.send(conflict_msg)
            except discord.Forbidden:
                pass
            await ctx.send("❌ Username conflict detected! Check your DMs.")
            return

        prediction = prediction.lower()
        if prediction not in ["player", "banker", "tie"]:
            await ctx.send("❌ Invalid prediction! Please choose: **player**, **banker**, or **tie**")
            return

        user_id = ctx.author.id
        predictions = prediction_systems['baccarat']['predictions']

        # Check if user already made a prediction
        if user_id in predictions:
            old_prediction = predictions[user_id]["prediction"]
            predictions[user_id] = {"prediction": prediction, "user": ctx.author, "kick_username": kick_username}

            # Send DM confirmation
            try:
                await ctx.author.send(f"✅ **Baccarat Prediction Updated!**\nChanged from **{old_prediction.upper()}** to **{prediction.upper()}**")
            except discord.Forbidden:
                pass  # User has DMs disabled

        else:
            # Register username
            await UserValidator.register_username(kick_username, 'baccarat', ctx.author.id, ctx.author)
            
            predictions[user_id] = {"prediction": prediction, "user": ctx.author, "kick_username": kick_username}

            # Record user participation
            await StatisticsManager.record_user_participation(kick_username, ctx.author.id, 'baccarat')

            # Send DM confirmation
            try:
                await ctx.author.send(f"✅ **Baccarat Prediction Confirmed!**\nYou predicted **{prediction.upper()}**")
            except discord.Forbidden:
                pass  # User has DMs disabled

        # Show current prediction count and list of kick usernames
        total_predictions = len(predictions)
        kick_usernames = [data["kick_username"] for data in predictions.values()]
        usernames_list = ", ".join(kick_usernames)

        await ctx.send(f"🎴 **{total_predictions}** player(s) have made baccarat predictions!\n🎮 **Players:** {usernames_list}")
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def open_baccarat_predictions(self, ctx):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        prediction_systems['baccarat']['active'] = True
        # Clear previous round's predictions when opening new round
        prediction_systems['baccarat']['predictions'].clear()
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('baccarat')
        
        # Get custom duration
        duration_minutes = TimerManager.get_custom_duration('baccarat')
        
        # Start timer
        await TimerManager.start_prediction_timer('baccarat', ctx, duration_minutes=duration_minutes)
        
        # Start activity monitoring
        await ActivityMonitor.start_reminder_monitoring('baccarat', ctx.channel)
        
        timestamp_str = TimerManager.get_discord_timestamp('baccarat') or f"in {duration_minutes} minutes"
        message = await ctx.send(f"✅ **Baccarat predictions are now OPEN!** 🎴\nUse `!predictbaccarat player/banker/tie YourKickUsername` to participate!\n⏰ **Auto-closes {timestamp_str}**")
        
        # Delete this message when predictions close
        await AdminUtils.schedule_message_deletion(message, 'baccarat')
        
        # Record statistics
        await StatisticsManager.record_prediction_opened('baccarat')
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def close_baccarat_predictions(self, ctx):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        prediction_systems['baccarat']['active'] = False
        prediction_count = len(prediction_systems['baccarat']['predictions'])
        
        # Cancel timer and stop activity monitoring
        TimerManager.cancel_timer('baccarat')
        ActivityMonitor.stop_reminder_monitoring('baccarat')
        
        # Delete pending messages
        await AdminUtils.delete_pending_messages('baccarat')
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('baccarat')
        
        # DON'T clear predictions yet - manual commands need them for winner checking
        await ctx.send(f"🔒 **Baccarat predictions are now CLOSED!** ({prediction_count} predictions recorded)")
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def trivia(self, ctx, *, question_and_answer=None):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        if not question_and_answer:
            await ctx.send("❌ Please provide question and answer: `!trivia What is 2+2? | 4`")
            return

        if " | " not in question_and_answer:
            await ctx.send("❌ Format: `!trivia Question here | Answer here`")
            return

        question, answer = question_and_answer.split(" | ", 1)
        
        # Generate random anti-bot words
        anti_bot_words = ["elephant", "rainbow", "keyboard", "mountain", "butterfly", "telescope", "sandwich", "umbrella", "dinosaur", "guitar"]
        required_word = random.choice(anti_bot_words)
        
        self.trivia_active = True
        self.trivia_answer = answer.lower().strip()
        self.trivia_required_word = required_word.lower()
        self.trivia_channel = ctx.channel

        # Create embed for trivia
        embed = discord.Embed(
            title="🧠 TRIVIA TIME! 🧠",
            description=f"**Question:** {question}",
            color=0x9932CC
        )
        embed.add_field(
            name="📝 How to Answer:",
            value=f"Include your answer, your Kick username, and the word **{required_word}**",
            inline=False
        )
        embed.add_field(
            name="💰 Prize:",
            value="Role-based reward (5.0 - 15.0) for the first correct answer!",
            inline=True
        )
        embed.set_footer(text="Anti-bot protection active • First correct answer wins")

        await ctx.send(embed=embed)

    @commands.Cog.listener()
    async def on_message(self, message):
        # Ignore bot messages
        if message.author.bot:
            return

        # Check trivia answers
        if self.trivia_active and message.channel == self.trivia_channel:
            content = message.content.lower()
            
            # Must contain the answer, "kick", and the required anti-bot word
            if (self.trivia_answer in content and 
                "kick" in content and 
                hasattr(self, 'trivia_required_word') and 
                self.trivia_required_word in content):
                
                # Extract kick username
                words = message.content.split()
                kick_username = "Unknown"
                
                for i, word in enumerate(words):
                    if word.lower() in ["kick", "kick:"]:
                        if i + 1 < len(words):
                            kick_username = words[i + 1].strip(".,!?")
                        break
                
                self.trivia_active = False
                self.trivia_answer = None
                self.trivia_channel = None
                self.trivia_required_word = None

                # Add reward with role-based amount
                prize_amount = self.get_user_prize_amount(message.author)
                self.add_winner_reward(kick_username, message.author)

                # Create winner embed
                embed = discord.Embed(
                    title="🎉 TRIVIA WINNER! 🎉",
                    description=f"**{kick_username}** got it right!",
                    color=0x00FF00
                )
                embed.add_field(
                    name="💰 Reward",
                    value=f"${prize_amount}",
                    inline=True
                )
                embed.add_field(
                    name="🏆 Winner",
                    value=kick_username,
                    inline=True
                )
                embed.set_footer(text="Congratulations! Check your balance.")

                await message.channel.send(embed=embed)

    def get_user_prize_amount(self, user):
        """Get prize amount based on user roles"""
        # Role-based rewards (customize as needed)
        if hasattr(user, 'roles'):
            for role in user.roles:
                if "VIP" in role.name.upper():
                    return "15.0"
                elif "PREMIUM" in role.name.upper():
                    return "12.0"
                elif "SUPPORTER" in role.name.upper():
                    return "10.0"
        
        return "5.0"  # Default amount

    def add_winner_reward(self, kick_username, discord_user):
        """Add winner to rewards system (placeholder)"""
        # This would integrate with your reward/balance system
        print(f"Added reward for {kick_username} (Discord: {discord_user.display_name})")

async def setup(bot):
    await bot.add_cog(BaccaratCog(bot))
