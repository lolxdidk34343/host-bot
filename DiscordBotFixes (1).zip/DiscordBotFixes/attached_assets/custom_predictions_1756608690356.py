import discord
from discord.ext import commands
import random
import json
from datetime import datetime
from admin_utils import AdminUtils
from timer_manager import TimerManager
from activity_monitor import ActivityMonitor
from persistence_manager import PersistenceManager
from statistics_manager import StatisticsManager
from user_validator import UserValidator

class CustomPredictionCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def check_custom_prediction_winners(self, ctx, winning_answer):
        from main import prediction_systems
        
        predictions = prediction_systems['custom']['predictions']
        winners = []
        kick_usernames_only = []
        all_participants = []
        total_players = len(predictions)

        for user_id, data in predictions.items():
            user = data["user"]
            prediction = data["prediction"]
            kick_username = data["kick_username"]
            all_participants.append(kick_username)
            
            # Check if prediction matches winning answer (case insensitive)
            if str(prediction).lower() == str(winning_answer).lower():
                winners.append((user, kick_username))
                kick_usernames_only.append(kick_username)

        if winners:
            # Create copy-paste friendly winner announcement
            winner_list = "\n".join(kick_usernames_only)
            await ctx.send(f"""🏆 **CUSTOM PREDICTION WINNERS!** 🎯

