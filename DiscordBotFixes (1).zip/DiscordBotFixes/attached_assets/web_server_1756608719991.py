from flask import Flask
import threading
import os

app = Flask(__name__)

@app.route('/')
def home():
    return "Discord Bot is running!"

@app.route('/health')
def health():
    return {"status": "healthy"}

def run():
    port = int(os.getenv('PORT', 5000))
    app.run(host='0.0.0.0', port=port)

def keep_alive():
    """Start the web server in a separate thread"""
    server = threading.Thread(target=run)
    server.daemon = True
    server.start()
