import discord
from typing import List, Dict, Any, Optional
import re

class UserValidator:
    """Validates user inputs and prevents common issues"""
    
    # Track usernames across all predictions to detect duplicates
    active_usernames = {}  # kick_username -> [(system_name, user_id, discord_user)]
    
    @staticmethod
    def validate_kick_username(kick_username: str) -> tuple[bool, str]:
        """Validate kick username format"""
        if not kick_username:
            return False, "❌ KickUsername is required!"
        
        if len(kick_username) < 2:
            return False, "❌ KickUsername must be at least 2 characters long!"
        
        if len(kick_username) > 25:
            return False, "❌ KickUsername cannot be longer than 25 characters!"
        
        # Check for invalid characters (basic validation)
        if not re.match(r'^[a-zA-Z0-9_]+$', kick_username):
            return False, "❌ KickUsername can only contain letters, numbers, and underscores!"
        
        return True, ""
    
    @staticmethod
    async def check_duplicate_username(kick_username: str, system_name: str, user_id: int, discord_user) -> Optional[str]:
        """Check if username is already being used by someone else"""
        kick_username_lower = kick_username.lower()
        
        if kick_username_lower in UserValidator.active_usernames:
            existing_entries = UserValidator.active_usernames[kick_username_lower]
            
            # Check if it's being used by a different Discord user
            for existing_system, existing_user_id, existing_discord_user in existing_entries:
                if existing_user_id != user_id:
                    # Different Discord user is using this username
                    return f"⚠️ **Username Conflict!** The KickUsername `{kick_username}` is already being used by **{existing_discord_user.display_name}** in **{existing_system.upper()}** predictions!\n\nPlease use your own KickUsername to avoid confusion."
        
        return None
    
    @staticmethod
    async def register_username(kick_username: str, system_name: str, user_id: int, discord_user):
        """Register a username as being used"""
        kick_username_lower = kick_username.lower()
        
        if kick_username_lower not in UserValidator.active_usernames:
            UserValidator.active_usernames[kick_username_lower] = []
        
        # Remove any existing entries for this user in this system
        UserValidator.active_usernames[kick_username_lower] = [
            entry for entry in UserValidator.active_usernames[kick_username_lower]
            if not (entry[0] == system_name and entry[1] == user_id)
        ]
        
        # Add new entry
        UserValidator.active_usernames[kick_username_lower].append((system_name, user_id, discord_user))
    
    @staticmethod
    async def unregister_username(kick_username: str, system_name: str, user_id: int):
        """Unregister a username when predictions close"""
        kick_username_lower = kick_username.lower()
        
        if kick_username_lower in UserValidator.active_usernames:
            UserValidator.active_usernames[kick_username_lower] = [
                entry for entry in UserValidator.active_usernames[kick_username_lower]
                if not (entry[0] == system_name and entry[1] == user_id)
            ]
            
            # Remove the key if no entries remain
            if not UserValidator.active_usernames[kick_username_lower]:
                del UserValidator.active_usernames[kick_username_lower]
    
    @staticmethod
    async def clear_system_usernames(system_name: str):
        """Clear all usernames for a specific system when predictions close"""
        # Remove all entries for this system
        for kick_username in list(UserValidator.active_usernames.keys()):
            UserValidator.active_usernames[kick_username] = [
                entry for entry in UserValidator.active_usernames[kick_username]
                if entry[0] != system_name
            ]
            
            # Remove empty lists
            if not UserValidator.active_usernames[kick_username]:
                del UserValidator.active_usernames[kick_username]
    
    @staticmethod
    async def validate_prediction_command(ctx, command_args: List[str], required_args: List[str]) -> tuple[bool, str, Dict[str, Any]]:
        """Validate a prediction command and extract arguments"""
        if len(command_args) < len(required_args):
            return False, f"❌ Missing arguments! Required: {' '.join(required_args)}", {}
        
        # Extract arguments
        parsed_args = {}
        for i, arg_name in enumerate(required_args):
            if i < len(command_args):
                parsed_args[arg_name] = command_args[i]
        
        # Special validation for kick_username (usually the last argument)
        if 'kick_username' in parsed_args:
            kick_username = parsed_args['kick_username']
            
            # Validate format
            is_valid, error_msg = UserValidator.validate_kick_username(kick_username)
            if not is_valid:
                try:
                    await ctx.author.send(f"**Invalid KickUsername Format**\n{error_msg}\n\nPlease use a valid KickUsername when making predictions.")
                except discord.Forbidden:
                    pass
                return False, error_msg, {}
            
            # Check for duplicates
            duplicate_msg = await UserValidator.check_duplicate_username(
                kick_username, 
                "unknown",  # Will be set by calling function
                ctx.author.id, 
                ctx.author
            )
            
            if duplicate_msg:
                try:
                    await ctx.author.send(duplicate_msg)
                except discord.Forbidden:
                    pass
                return False, "❌ Username conflict detected! Check your DMs.", {}
        
        return True, "", parsed_args
    
    @staticmethod
    async def send_missing_username_notification(ctx):
        """Send notification for missing KickUsername"""
        try:
            await ctx.author.send(
                "❌ **Missing KickUsername!**\n\n"
                "You forgot to include your KickUsername in your prediction command!\n\n"
                "**Correct format:** `!command prediction YourKickUsername`\n"
                "**Example:** `!predictdice 7 MyKickName`\n\n"
                "Please try again with your KickUsername included."
            )
        except discord.Forbidden:
            # User has DMs disabled, send public message
            await ctx.send(f"{ctx.author.mention} ❌ You forgot to include your KickUsername! Check the command format and try again.")
    
    @staticmethod
    async def get_username_conflicts() -> Dict[str, List]:
        """Get current username conflicts for admin review"""
        conflicts = {}
        
        for kick_username, entries in UserValidator.active_usernames.items():
            if len(entries) > 1:
                # Multiple users using same username
                user_info = []
                for system_name, user_id, discord_user in entries:
                    user_info.append({
                        "system": system_name,
                        "discord_user": discord_user.display_name,
                        "user_id": user_id
                    })
                conflicts[kick_username] = user_info
        
        return conflicts
