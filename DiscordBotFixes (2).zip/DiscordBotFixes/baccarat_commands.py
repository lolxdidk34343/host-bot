import discord
from discord.ext import commands
import random
import json
from datetime import datetime
from admin_utils import AdminUtils
from timer_manager import TimerManager
from activity_monitor import ActivityMonitor
from persistence_manager import PersistenceManager
from statistics_manager import StatisticsManager
from user_validator import UserValidator

class BaccaratCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def check_baccarat_prediction_winners(self, ctx, result):
        from main import prediction_systems
        
        predictions = prediction_systems['baccarat']['predictions']
        winners = []
        kick_usernames_only = []
        all_participants = []
        total_players = len(predictions)

        for user_id, prediction_data in predictions.items():
            user_prediction = prediction_data["prediction"]
            user = prediction_data["user"]
            kick_username = prediction_data.get("kick_username", "Unknown")
            all_participants.append(kick_username)

            # Check if prediction matches
            if user_prediction.lower() == result.lower():
                kick_usernames_only.append(kick_username)

        # Send results
        if kick_usernames_only:
            winner_list = "\n".join(kick_usernames_only)
            copy_paste_box = f"```\n{winner_list}\n```"
            
            await ctx.send(f"🎉 **BACCARAT PREDICTION WINNERS!** 🎉\n{copy_paste_box}Correctly predicted **{result.upper()}**!\n\n📊 **{len(kick_usernames_only)}/{total_players}** players won!")
        else:
            await ctx.send(f"😔 **NO BACCARAT WINNERS!** 😔\nNone of the **{total_players}** players predicted **{result.upper()}** correctly.\nBetter luck next time!")

        # Record statistics
        await StatisticsManager.record_prediction_result('baccarat', kick_usernames_only, all_participants)

        # Clear predictions for next round
        prediction_systems['baccarat']['predictions'].clear()
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('baccarat')
        
        await PersistenceManager.save_data()

    @commands.command()
    async def baccarat(self, ctx):
        # Random baccarat result
        result = random.choice(["player", "banker", "tie"])

        # Announce result
        await ctx.send(f"""🃏 **BACCARAT RESULT** 🃏

🎯 **{result.upper()} WINS!**

*Random result*""")

        # Check for winners if predictions were made
        from main import prediction_systems
        if prediction_systems['baccarat']['predictions']:
            await self.check_baccarat_prediction_winners(ctx, result)

    @commands.command()
    async def baccarat_manual(self, ctx, result: str = ""):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        if not result:
            await ctx.send("❌ Please specify the result: `!baccarat_manual player/banker/tie`")
            return

        result = result.lower()
        if result not in ["player", "banker", "tie"]:
            await ctx.send("❌ Result must be: **player**, **banker**, or **tie**")
            return

        # Send manual result
        await ctx.send(f"🃏 **Manual Baccarat Result:** **{result.upper()} WINS!** 🔧")

        # Check for winners if predictions were made
        from main import prediction_systems
        if prediction_systems['baccarat']['predictions']:
            await self.check_baccarat_prediction_winners(ctx, result)

    @commands.command()
    async def predictbaccarat(self, ctx, prediction: str = "", *, kick_username: str = ""):
        from main import prediction_systems
        
        # Check if wrong prediction system is being used
        error_msg = AdminUtils.check_wrong_prediction_command(ctx, 'baccarat')
        if error_msg and 'baccarat' not in AdminUtils.get_active_predictions():
            await ctx.send(error_msg)
            return

        if not prediction_systems['baccarat']['active']:
            await ctx.send("❌ Baccarat predictions are currently closed! Wait for an admin to open them.")
            return

        if not prediction or not kick_username:
            await UserValidator.send_missing_username_notification(ctx)
            await ctx.send("❌ Please specify both prediction and kick username: `!predictbaccarat player YourKickUsername`")
            return

        # Validate kick username
        is_valid, error_msg = UserValidator.validate_kick_username(kick_username)
        if not is_valid:
            try:
                await ctx.author.send(f"**Invalid KickUsername Format**\n{error_msg}")
            except discord.Forbidden:
                pass
            await ctx.send("❌ Invalid KickUsername format! Check your DMs for details.")
            return

        # Check for username conflicts
        conflict_msg = await UserValidator.check_duplicate_username(kick_username, 'baccarat', ctx.author.id, ctx.author)
        if conflict_msg:
            try:
                await ctx.author.send(conflict_msg)
            except discord.Forbidden:
                pass
            await ctx.send("❌ Username conflict detected! Check your DMs.")
            return

        prediction = prediction.lower()
        if prediction not in ["player", "banker", "tie"]:
            await ctx.send("❌ Invalid prediction! Please choose: **player**, **banker**, or **tie**")
            return

        user_id = ctx.author.id
        predictions = prediction_systems['baccarat']['predictions']

        # Check if user already made a prediction
        if user_id in predictions:
            old_prediction = predictions[user_id]["prediction"]
            predictions[user_id] = {"prediction": prediction, "user": ctx.author, "kick_username": kick_username}

            # Send DM confirmation
            try:
                await ctx.author.send(f"✅ **Baccarat Prediction Updated!**\nChanged from **{old_prediction.upper()}** to **{prediction.upper()}**")
            except discord.Forbidden:
                pass  # User has DMs disabled

        else:
            # Register username
            await UserValidator.register_username(kick_username, 'baccarat', ctx.author.id, ctx.author)
            
            predictions[user_id] = {"prediction": prediction, "user": ctx.author, "kick_username": kick_username}

            # Record user participation
            await StatisticsManager.record_user_participation(kick_username, ctx.author.id, 'baccarat')

            # Send DM confirmation
            try:
                await ctx.author.send(f"✅ **Baccarat Prediction Confirmed!**\nYou predicted **{prediction.upper()}**")
            except discord.Forbidden:
                pass  # User has DMs disabled

        # Show current prediction count and list of kick usernames
        total_predictions = len(predictions)
        kick_usernames = [data["kick_username"] for data in predictions.values()]
        usernames_list = ", ".join(kick_usernames)

        await ctx.send(f"🃏 **{total_predictions}** player(s) have made baccarat predictions!\n🎮 **Players:** {usernames_list}")
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def open_baccarat_predictions(self, ctx):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        prediction_systems['baccarat']['active'] = True
        # Clear previous round's predictions when opening new round
        prediction_systems['baccarat']['predictions'].clear()
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('baccarat')
        
        # Get custom duration
        duration_minutes = TimerManager.get_custom_duration('baccarat')
        
        # Start timer
        await TimerManager.start_prediction_timer('baccarat', ctx, duration_minutes=duration_minutes)
        
        # Start activity monitoring
        await ActivityMonitor.start_reminder_monitoring('baccarat', ctx.channel)
        
        timestamp_str = TimerManager.get_discord_timestamp('baccarat') or f"in {duration_minutes} minutes"
        message = await ctx.send(f"✅ **Baccarat predictions are now OPEN!** 🃏\nUse `!predictbaccarat player/banker/tie YourKickUsername` to participate!\n⏰ **Auto-closes {timestamp_str}**")
        
        # Delete this message when predictions close
        await AdminUtils.schedule_message_deletion(message, 'baccarat')
        
        # Record statistics
        await StatisticsManager.record_prediction_opened('baccarat')
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def close_baccarat_predictions(self, ctx):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        prediction_systems['baccarat']['active'] = False
        prediction_count = len(prediction_systems['baccarat']['predictions'])
        
        # Cancel timer and stop activity monitoring
        TimerManager.cancel_timer('baccarat')
        ActivityMonitor.stop_reminder_monitoring('baccarat')
        
        # Delete pending messages
        await AdminUtils.delete_pending_messages('baccarat')
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('baccarat')
        
        await ctx.send(f"🔒 **Baccarat predictions are now CLOSED!** ({prediction_count} predictions recorded)")
        
        # Save data
        await PersistenceManager.save_data()

async def setup(bot):
    await bot.add_cog(BaccaratCog(bot))
