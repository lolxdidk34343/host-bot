import discord
from discord.ext import commands
import json
import os
import asyncio
from datetime import datetime
from web_server import keep_alive
from persistence_manager import PersistenceManager
from statistics_manager import StatisticsManager
from activity_monitor import ActivityMonitor
from admin_utils import setup_admin_commands

# Bot configuration
DISCORD_TOKEN = 'MTAwMDk2NjEzMTA5NzUzODU4MQ.GzPNi0.hpbQVUvVaPJlAExvoImOGn8tWAR-1mhZcywrb8'
intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True

bot = commands.Bot(command_prefix='!', intents=intents, help_command=None)

# Global prediction systems data
prediction_systems = {
    "roulette": {
        "active": False,
        "auto_loop": False,
        "predictions": {}
    },
    "blackjack": {
        "active": False,
        "auto_loop": False,
        "predictions": {}
    },
    "baccarat": {
        "active": False,
        "auto_loop": False,
        "predictions": {}
    },
    "dice": {
        "active": False,
        "auto_loop": False,
        "predictions": {}
    },
    "limbo": {
        "active": False,
        "auto_loop": False,
        "predictions": {}
    },
    "marble": {
        "active": False,
        "auto_loop": False,
        "predictions": {}
    },
    "custom": {
        "active": False,
        "auto_loop": False,
        "predictions": {},
        "question": "",
        "options": []
    },
    "slotcall": {
        "active": False,
        "auto_loop": False,
        "predictions": {}
    }
}

@bot.event
async def on_ready():
    print(f'{bot.user} has connected to Discord!')
    
    # Initialize managers
    await PersistenceManager.initialize(bot)
    await StatisticsManager.initialize()
    ActivityMonitor.start_monitoring(bot)
    
    # Load existing data
    await PersistenceManager.load_data()
    
    # Set up admin commands
    setup_admin_commands(bot)
    
    # Sync slash commands
    try:
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} slash commands")
    except Exception as e:
        print(f"Failed to sync slash commands: {e}")

@bot.event
async def on_message(message):
    if message.author.bot:
        return
    
    # Update activity monitoring
    ActivityMonitor.update_activity(message.channel.id)
    
    # Process commands
    await bot.process_commands(message)

# Load all command cogs
async def load_cogs():
    extensions = [
        'dice_commands',
        'custom_predictions', 
        'blackjack_commands',
        'baccarat_commands',
        'roulette_commands',
        'limbo_commands',
        'marble_commands',
        'slotcall_commands',
        'slash_commands'
    ]
    
    for extension in extensions:
        try:
            await bot.load_extension(extension)
            print(f'Loaded {extension}')
        except Exception as e:
            print(f'Failed to load {extension}: {e}')

# Basic help command
@bot.command()
async def help(ctx):
    embed = discord.Embed(
        title="🎲 Prediction Bot Commands",
        description="Available prediction commands:",
        color=0x9932CC
    )
    
    embed.add_field(
        name="🎯 Prediction Commands",
        value="""
        `!predict` - Roulette predictions
        `!predictbj` - Blackjack predictions
        `!predictbaccarat` - Baccarat predictions
        `!predictdice` - Dice predictions
        `!predictlimbo` - Limbo predictions
        `!predictmarble` - Marble predictions
        `!predictcustom` - Custom predictions
        `!slotcall` - Slot call predictions
        """,
        inline=False
    )
    
    embed.add_field(
        name="📊 Information",
        value="`!stats` - View prediction statistics (Admin only)",
        inline=False
    )
    
    await ctx.send(embed=embed)

async def main():
    # Start the web server
    keep_alive()
    
    # Load cogs
    await load_cogs()
    
    # Start the bot
    await bot.start(DISCORD_TOKEN)

if __name__ == "__main__":
    asyncio.run(main())
