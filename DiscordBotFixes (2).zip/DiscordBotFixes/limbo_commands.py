import discord
from discord.ext import commands
import random
import json
from datetime import datetime
from admin_utils import AdminUtils
from timer_manager import TimerManager
from activity_monitor import ActivityMonitor
from persistence_manager import PersistenceManager
from statistics_manager import StatisticsManager
from user_validator import UserValidator

class LimboCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def check_limbo_prediction_winners(self, ctx, multiplier):
        from main import prediction_systems
        
        predictions = prediction_systems['limbo']['predictions']
        winners = []
        kick_usernames_only = []
        all_participants = []
        total_players = len(predictions)

        for user_id, prediction_data in predictions.items():
            user_prediction = prediction_data["prediction"]
            user = prediction_data["user"]
            kick_username = prediction_data.get("kick_username", "Unknown")
            all_participants.append(kick_username)

            # Check if prediction matches (user prediction must be <= actual multiplier to win)
            try:
                pred_multiplier = float(user_prediction)
                if pred_multiplier <= multiplier:
                    kick_usernames_only.append(kick_username)
            except ValueError:
                pass  # Invalid prediction format

        # Send results
        if kick_usernames_only:
            winner_list = "\n".join(kick_usernames_only)
            copy_paste_box = f"```\n{winner_list}\n```"
            
            await ctx.send(f"🎉 **LIMBO PREDICTION WINNERS!** 🎉\n{copy_paste_box}Correctly predicted **{multiplier}x** or lower!\n\n📊 **{len(kick_usernames_only)}/{total_players}** players won!")
        else:
            await ctx.send(f"😔 **NO LIMBO WINNERS!** 😔\nNone of the **{total_players}** players predicted **{multiplier}x** or lower correctly.\nBetter luck next time!")

        # Record statistics
        await StatisticsManager.record_prediction_result('limbo', kick_usernames_only, all_participants)

        # Clear predictions for next round
        prediction_systems['limbo']['predictions'].clear()
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('limbo')
        
        await PersistenceManager.save_data()

    @commands.command()
    async def limbo(self, ctx):
        # Generate random multiplier (1.0 to 20.0)
        multiplier = round(random.uniform(1.0, 20.0), 2)

        # Announce result
        await ctx.send(f"""🚀 **LIMBO RESULT** 🚀

🎯 **{multiplier}x**

*Random result*""")

        # Check for winners if predictions were made
        from main import prediction_systems
        if prediction_systems['limbo']['predictions']:
            await self.check_limbo_prediction_winners(ctx, multiplier)

    @commands.command()
    async def limbo_manual(self, ctx, result: str = ""):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        if not result:
            await ctx.send("❌ Please specify the result: `!limbo_manual 5.5`")
            return

        try:
            multiplier = float(result)
            if multiplier < 1.0 or multiplier > 1000.0:
                raise ValueError()
        except ValueError:
            await ctx.send("❌ Result must be a valid multiplier (1.0 - 1000.0)")
            return

        # Send manual result
        await ctx.send(f"🚀 **Manual Limbo Result:** **{multiplier}x** 🔧")

        # Check for winners if predictions were made
        from main import prediction_systems
        if prediction_systems['limbo']['predictions']:
            await self.check_limbo_prediction_winners(ctx, multiplier)

    @commands.command()
    async def predictlimbo(self, ctx, prediction: str = "", *, kick_username: str = ""):
        from main import prediction_systems
        
        # Check if wrong prediction system is being used
        error_msg = AdminUtils.check_wrong_prediction_command(ctx, 'limbo')
        if error_msg and 'limbo' not in AdminUtils.get_active_predictions():
            await ctx.send(error_msg)
            return

        if not prediction_systems['limbo']['active']:
            await ctx.send("❌ Limbo predictions are currently closed! Wait for an admin to open them.")
            return

        if not prediction or not kick_username:
            await UserValidator.send_missing_username_notification(ctx)
            await ctx.send("❌ Please specify both prediction and kick username: `!predictlimbo 5.5 YourKickUsername`")
            return

        # Validate kick username
        is_valid, error_msg = UserValidator.validate_kick_username(kick_username)
        if not is_valid:
            try:
                await ctx.author.send(f"**Invalid KickUsername Format**\n{error_msg}")
            except discord.Forbidden:
                pass
            await ctx.send("❌ Invalid KickUsername format! Check your DMs for details.")
            return

        # Check for username conflicts
        conflict_msg = await UserValidator.check_duplicate_username(kick_username, 'limbo', ctx.author.id, ctx.author)
        if conflict_msg:
            try:
                await ctx.author.send(conflict_msg)
            except discord.Forbidden:
                pass
            await ctx.send("❌ Username conflict detected! Check your DMs.")
            return

        # Validate prediction
        try:
            pred_multiplier = float(prediction)
            if pred_multiplier < 1.0 or pred_multiplier > 1000.0:
                raise ValueError()
        except ValueError:
            await ctx.send("❌ Invalid prediction! Please provide a multiplier between 1.0 and 1000.0")
            return

        user_id = ctx.author.id
        predictions = prediction_systems['limbo']['predictions']

        # Check if user already made a prediction
        if user_id in predictions:
            old_prediction = predictions[user_id]["prediction"]
            predictions[user_id] = {"prediction": prediction, "user": ctx.author, "kick_username": kick_username}

            # Send DM confirmation
            try:
                await ctx.author.send(f"✅ **Limbo Prediction Updated!**\nChanged from **{old_prediction}x** to **{prediction}x**")
            except discord.Forbidden:
                pass  # User has DMs disabled

        else:
            # Register username
            await UserValidator.register_username(kick_username, 'limbo', ctx.author.id, ctx.author)
            
            predictions[user_id] = {"prediction": prediction, "user": ctx.author, "kick_username": kick_username}

            # Record user participation
            await StatisticsManager.record_user_participation(kick_username, ctx.author.id, 'limbo')

            # Send DM confirmation
            try:
                await ctx.author.send(f"✅ **Limbo Prediction Confirmed!**\nYou predicted **{prediction}x**")
            except discord.Forbidden:
                pass  # User has DMs disabled

        # Show current prediction count and list of kick usernames
        total_predictions = len(predictions)
        kick_usernames = [data["kick_username"] for data in predictions.values()]
        usernames_list = ", ".join(kick_usernames)

        await ctx.send(f"🚀 **{total_predictions}** player(s) have made limbo predictions!\n🎮 **Players:** {usernames_list}")
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def open_limbo_predictions(self, ctx):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        prediction_systems['limbo']['active'] = True
        # Clear previous round's predictions when opening new round
        prediction_systems['limbo']['predictions'].clear()
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('limbo')
        
        # Get custom duration
        duration_minutes = TimerManager.get_custom_duration('limbo')
        
        # Start timer
        await TimerManager.start_prediction_timer('limbo', ctx, duration_minutes=duration_minutes)
        
        # Start activity monitoring
        await ActivityMonitor.start_reminder_monitoring('limbo', ctx.channel)
        
        timestamp_str = TimerManager.get_discord_timestamp('limbo') or f"in {duration_minutes} minutes"
        message = await ctx.send(f"✅ **Limbo predictions are now OPEN!** 🚀\nUse `!predictlimbo 5.5 YourKickUsername` to participate!\n⏰ **Auto-closes {timestamp_str}**")
        
        # Delete this message when predictions close
        await AdminUtils.schedule_message_deletion(message, 'limbo')
        
        # Record statistics
        await StatisticsManager.record_prediction_opened('limbo')
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def close_limbo_predictions(self, ctx):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        prediction_systems['limbo']['active'] = False
        prediction_count = len(prediction_systems['limbo']['predictions'])
        
        # Cancel timer and stop activity monitoring
        TimerManager.cancel_timer('limbo')
        ActivityMonitor.stop_reminder_monitoring('limbo')
        
        # Delete pending messages
        await AdminUtils.delete_pending_messages('limbo')
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('limbo')
        
        await ctx.send(f"🔒 **Limbo predictions are now CLOSED!** ({prediction_count} predictions recorded)")
        
        # Save data
        await PersistenceManager.save_data()

async def setup(bot):
    await bot.add_cog(LimboCog(bot))
