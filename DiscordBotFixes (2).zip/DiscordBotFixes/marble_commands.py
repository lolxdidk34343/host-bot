import discord
from discord.ext import commands
import random
import json
from datetime import datetime
from admin_utils import AdminUtils
from timer_manager import TimerManager
from activity_monitor import ActivityMonitor
from persistence_manager import PersistenceManager
from statistics_manager import StatisticsManager
from user_validator import UserValidator

class MarbleCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def check_marble_prediction_winners(self, ctx, result):
        from main import prediction_systems
        
        predictions = prediction_systems['marble']['predictions']
        winners = []
        kick_usernames_only = []
        all_participants = []
        total_players = len(predictions)

        for user_id, prediction_data in predictions.items():
            user_predictions = prediction_data["predictions"]  # Now a list of up to 2 colors
            user = prediction_data["user"]
            kick_username = prediction_data.get("kick_username", "Unknown")
            all_participants.append(kick_username)

            # Check if any prediction matches (case insensitive)
            if any(pred.upper() == result.upper() for pred in user_predictions):
                kick_usernames_only.append(kick_username)

        # Send results
        if kick_usernames_only:
            winner_list = "\n".join(kick_usernames_only)
            copy_paste_box = f"```\n{winner_list}\n```"
            
            await ctx.send(f"🎉 **MARBLE PREDICTION WINNERS!** 🎉\n{copy_paste_box}Correctly predicted **{result}**!\n\n📊 **{len(kick_usernames_only)}/{total_players}** players won!")
        else:
            await ctx.send(f"😔 **NO MARBLE WINNERS!** 😔\nNone of the **{total_players}** players predicted **{result}** correctly.\nBetter luck next time!")

        # Record statistics
        await StatisticsManager.record_prediction_result('marble', kick_usernames_only, all_participants)

        # Clear predictions for next round
        prediction_systems['marble']['predictions'].clear()
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('marble')
        
        await PersistenceManager.save_data()

    @commands.command()
    async def marble(self, ctx):
        # Random marble result (color)
        colors = ["RED", "BLUE", "YELLOW", "WHITE", "BLACK", "GREEN"]
        result = random.choice(colors)

        # Announce result
        await ctx.send(f"""🔮 **MARBLE RESULT** 🔮

🎯 **{result}**

*Random result*""")

        # Check for winners if predictions were made
        from main import prediction_systems
        if prediction_systems['marble']['predictions']:
            await self.check_marble_prediction_winners(ctx, result)

    @commands.command()
    async def marble_manual(self, ctx, result: str = ""):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        if not result:
            await ctx.send("❌ Please specify the result: `!marble_manual RED` (Colors: RED, BLUE, YELLOW, WHITE, BLACK, GREEN)")
            return

        result = result.upper()
        valid_colors = ["RED", "BLUE", "YELLOW", "WHITE", "BLACK", "GREEN"]
        if result not in valid_colors:
            await ctx.send(f"❌ Invalid color! Valid colors: **{', '.join(valid_colors)}**")
            return

        # Send manual result
        await ctx.send(f"🔮 **Manual Marble Result:** **{result}** 🔧")

        # Check for winners if predictions were made
        from main import prediction_systems
        if prediction_systems['marble']['predictions']:
            await self.check_marble_prediction_winners(ctx, result)

    @commands.command()
    async def predictmarble(self, ctx, prediction: str = "", *, kick_username: str = ""):
        from main import prediction_systems
        
        # Check if wrong prediction system is being used
        error_msg = AdminUtils.check_wrong_prediction_command(ctx, 'marble')
        if error_msg and 'marble' not in AdminUtils.get_active_predictions():
            await ctx.send(error_msg)
            return

        if not prediction_systems['marble']['active']:
            await ctx.send("❌ Marble predictions are currently closed! Wait for an admin to open them.")
            return

        if not prediction or not kick_username:
            await UserValidator.send_missing_username_notification(ctx)
            await ctx.send("❌ Please specify both prediction and kick username: `!predictmarble RED YourKickUsername` (Colors: RED, BLUE, YELLOW, WHITE, BLACK, GREEN)")
            return

        # Validate kick username
        is_valid, error_msg = UserValidator.validate_kick_username(kick_username)
        if not is_valid:
            try:
                await ctx.author.send(f"**Invalid KickUsername Format**\n{error_msg}")
            except discord.Forbidden:
                pass
            await ctx.send("❌ Invalid KickUsername format! Check your DMs for details.")
            return

        # Check for username conflicts
        conflict_msg = await UserValidator.check_duplicate_username(kick_username, 'marble', ctx.author.id, ctx.author)
        if conflict_msg:
            try:
                await ctx.author.send(conflict_msg)
            except discord.Forbidden:
                pass
            await ctx.send("❌ Username conflict detected! Check your DMs.")
            return

        # Validate prediction (color)
        valid_colors = ["RED", "BLUE", "YELLOW", "WHITE", "BLACK", "GREEN"]
        prediction = prediction.upper()
        if prediction not in valid_colors:
            await ctx.send(f"❌ Invalid color! Valid colors: **{', '.join(valid_colors)}**")
            return

        user_id = ctx.author.id
        predictions = prediction_systems['marble']['predictions']

        # Check if user already made predictions
        if user_id in predictions:
            current_predictions = predictions[user_id]["predictions"]
            
            # Check if they already have 2 guesses
            if len(current_predictions) >= 2:
                # Replace one of their existing predictions
                if prediction in current_predictions:
                    await ctx.send("❌ You already predicted that color! Choose a different one.")
                    return
                
                # Replace the first prediction
                old_prediction = current_predictions[0]
                current_predictions[0] = prediction
                
                # Send DM confirmation
                try:
                    await ctx.author.send(f"✅ **Marble Prediction Updated!**\nReplaced **{old_prediction}** with **{prediction}**\nYour predictions: **{', '.join(current_predictions)}**")
                except discord.Forbidden:
                    pass
            else:
                # Add second prediction
                if prediction in current_predictions:
                    await ctx.send("❌ You already predicted that color! Choose a different one.")
                    return
                
                current_predictions.append(prediction)
                
                # Send DM confirmation
                try:
                    await ctx.author.send(f"✅ **Marble Prediction Added!**\nYour predictions: **{', '.join(current_predictions)}**")
                except discord.Forbidden:
                    pass
        else:
            # Register username and first prediction
            await UserValidator.register_username(kick_username, 'marble', ctx.author.id, ctx.author)
            
            predictions[user_id] = {"predictions": [prediction], "user": ctx.author, "kick_username": kick_username}

            # Record user participation
            await StatisticsManager.record_user_participation(kick_username, ctx.author.id, 'marble')

            # Send DM confirmation
            try:
                await ctx.author.send(f"✅ **Marble Prediction Confirmed!**\nYou predicted **{prediction}** (1/2 guesses used)")
            except discord.Forbidden:
                pass  # User has DMs disabled

        # Show current prediction count and list of kick usernames
        total_predictions = len(predictions)
        kick_usernames = [data["kick_username"] for data in predictions.values()]
        usernames_list = ", ".join(kick_usernames)

        await ctx.send(f"🔮 **{total_predictions}** player(s) have made marble predictions!\n🎮 **Players:** {usernames_list}")
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def open_marble_predictions(self, ctx):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        prediction_systems['marble']['active'] = True
        # Clear previous round's predictions when opening new round
        prediction_systems['marble']['predictions'].clear()
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('marble')
        
        # Get custom duration
        duration_minutes = TimerManager.get_custom_duration('marble')
        
        # Start timer
        await TimerManager.start_prediction_timer('marble', ctx, duration_minutes=duration_minutes)
        
        # Start activity monitoring
        await ActivityMonitor.start_reminder_monitoring('marble', ctx.channel)
        
        timestamp_str = TimerManager.get_discord_timestamp('marble') or f"in {duration_minutes} minutes"
        message = await ctx.send(f"✅ **Marble predictions are now OPEN!** 🔮\nUse `!predictmarble COLOR YourKickUsername` to participate!\n🎨 **Colors:** RED, BLUE, YELLOW, WHITE, BLACK, GREEN\n🎯 **You get 2 guesses each!**\n⏰ **Auto-closes {timestamp_str}**")
        
        # Delete this message when predictions close
        await AdminUtils.schedule_message_deletion(message, 'marble')
        
        # Record statistics
        await StatisticsManager.record_prediction_opened('marble')
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def close_marble_predictions(self, ctx):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        prediction_systems['marble']['active'] = False
        prediction_count = len(prediction_systems['marble']['predictions'])
        
        # Cancel timer and stop activity monitoring
        TimerManager.cancel_timer('marble')
        ActivityMonitor.stop_reminder_monitoring('marble')
        
        # Delete pending messages
        await AdminUtils.delete_pending_messages('marble')
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('marble')
        
        await ctx.send(f"🔒 **Marble predictions are now CLOSED!** ({prediction_count} predictions recorded)")
        
        # Save data
        await PersistenceManager.save_data()

async def setup(bot):
    await bot.add_cog(MarbleCog(bot))
