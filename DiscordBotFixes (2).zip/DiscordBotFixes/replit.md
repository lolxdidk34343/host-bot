# Discord Prediction Bot

## Overview

This is a Discord bot designed for gambling prediction games. Users can make predictions on various casino games including Roulette, Blackjack, Baccarat, Dice, Limbo, Marble, and custom prediction systems. The bot manages prediction timers, tracks user statistics, validates user inputs, and provides admin controls for managing prediction rounds.

The bot features a modular architecture with separate components for each game type, comprehensive statistics tracking, data persistence, activity monitoring, and admin utilities. It's designed to handle multiple concurrent prediction systems with customizable timers and automatic result processing.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Core Bot Framework
- **Discord.py Framework**: Uses discord.py with command extensions and slash commands
- **Command Structure**: Prefix-based commands (!command) and slash commands for admin functions
- **Event-Driven Architecture**: Bot responds to Discord events and user interactions

### Game System Architecture
- **Modular Game Commands**: Each game type (Roulette, Blackjack, etc.) has its own command cog
- **Unified Prediction System**: Global prediction_systems dictionary manages all active predictions
- **State Management**: Each game maintains active/inactive state, auto-loop settings, and user predictions

### Timer and Activity Management
- **TimerManager**: Handles prediction timers with customizable durations (1-60 minutes, default 4 minutes)
- **ActivityMonitor**: Tracks channel activity and sends reminders during inactive periods
- **Auto-Close Functionality**: Automatically closes predictions when timers expire

### Data Persistence
- **JSON File Storage**: Uses predictions_data.json for persistent data storage
- **PersistenceManager**: Handles serialization of Discord objects and system state
- **Statistics Tracking**: Comprehensive user win/loss statistics and participation counts

### User Validation and Security
- **UserValidator**: Validates usernames and prevents duplicate entries across systems
- **AdminUtils**: Role-based permission system for admin commands
- **Input Validation**: Prevents invalid usernames and malformed predictions

### Statistics System
- **StatisticsManager**: Tracks total predictions, user participation, win rates
- **Daily Statistics**: Daily breakdown of predictions and participants
- **User Performance Tracking**: Individual user win counts and participation history

### Web Server Integration
- **Flask Web Server**: Basic web server for health checks and uptime monitoring
- **Replit Compatibility**: Designed to run on Replit with keep-alive functionality

### Admin Controls
- **Permission-Based Access**: Admin commands restricted to users with specific roles
- **Manual Result Override**: Admins can manually set prediction results
- **Custom Timer Configuration**: Per-game timer customization
- **System Management**: Start/stop predictions and manage auto-loops

## External Dependencies

### Core Dependencies
- **discord.py**: Discord API wrapper for bot functionality
- **Flask**: Web server for health checks and uptime monitoring
- **aiohttp**: Async HTTP client for API monitoring (unused in current implementation)

### Python Standard Library
- **asyncio**: Asynchronous programming support for timers and concurrent operations
- **json**: Data serialization for persistence
- **datetime**: Timer management and statistics timestamps
- **collections.defaultdict**: Statistics data structures
- **re**: Regular expression validation for usernames
- **os**: Environment variable access for tokens and configuration
- **threading**: Web server threading

### Discord Integration
- **Discord Bot Token**: Required environment variable for bot authentication
- **Discord Permissions**: Message content intent and guild access required
- **Role-Based Authentication**: Specific Discord role IDs for admin access

### File System
- **predictions_data.json**: Persistent storage file for all bot data
- **Replit File System**: Bot designed to work with Replit's file system constraints

### Hosting Platform
- **Replit Environment**: Optimized for Replit hosting with PORT environment variable
- **Environment Variables**: DISCORD_TOKEN for authentication
- **Keep-Alive System**: Web server prevents Replit from sleeping the application