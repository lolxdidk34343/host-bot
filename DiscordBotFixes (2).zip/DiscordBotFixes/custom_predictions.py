import discord
from discord.ext import commands
import random
import json
from datetime import datetime
from admin_utils import AdminUtils
from timer_manager import TimerManager
from activity_monitor import ActivityMonitor
from persistence_manager import PersistenceManager
from statistics_manager import StatisticsManager
from user_validator import UserValidator

class CustomPredictionCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def check_custom_prediction_winners(self, ctx, winning_answer):
        from main import prediction_systems
        
        predictions = prediction_systems['custom']['predictions']
        winners = []
        kick_usernames_only = []
        all_participants = []
        total_players = len(predictions)

        for user_id, data in predictions.items():
            user = data["user"]
            prediction = data["prediction"]
            kick_username = data["kick_username"]
            all_participants.append(kick_username)
            
            # Check if prediction matches winning answer (case insensitive)
            if str(prediction).lower() == str(winning_answer).lower():
                winners.append((user, kick_username))
                kick_usernames_only.append(kick_username)

        if winners:
            # Create copy-paste friendly winner announcement
            winner_list = "\n".join(kick_usernames_only)
            copy_paste_box = f"```\n{winner_list}\n```"
            
            await ctx.send(f"🏆 **CUSTOM PREDICTION WINNERS!** 🎯\n\n{copy_paste_box}Correctly predicted **{winning_answer}**!\n\n📊 **{len(kick_usernames_only)}/{total_players}** players won!")
        else:
            await ctx.send(f"😔 **NO CUSTOM PREDICTION WINNERS!** 😔\nNone of the **{total_players}** players predicted **{winning_answer}** correctly.\nBetter luck next time!")

        # Record statistics
        await StatisticsManager.record_prediction_result('custom', kick_usernames_only, all_participants)

        # Clear predictions for next round
        prediction_systems['custom']['predictions'].clear()
        prediction_systems['custom']['question'] = ""
        prediction_systems['custom']['options'] = []
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('custom')
        
        await PersistenceManager.save_data()

    @commands.command()
    async def predictcustom(self, ctx, prediction: str = "", *, kick_username: str = ""):
        from main import prediction_systems
        
        # Check if wrong prediction system is being used
        error_msg = AdminUtils.check_wrong_prediction_command(ctx, 'custom')
        if error_msg and 'custom' not in AdminUtils.get_active_predictions():
            await ctx.send(error_msg)
            return

        if not prediction_systems['custom']['active']:
            await ctx.send("❌ Custom predictions are currently closed! Wait for an admin to open them.")
            return

        if not prediction or not kick_username:
            await UserValidator.send_missing_username_notification(ctx)
            await ctx.send("❌ Please specify both prediction and kick username: `!predictcustom answer YourKickUsername`")
            return

        # Validate kick username
        is_valid, error_msg = UserValidator.validate_kick_username(kick_username)
        if not is_valid:
            try:
                await ctx.author.send(f"**Invalid KickUsername Format**\n{error_msg}")
            except discord.Forbidden:
                pass
            await ctx.send("❌ Invalid KickUsername format! Check your DMs for details.")
            return

        # Check for username conflicts
        conflict_msg = await UserValidator.check_duplicate_username(kick_username, 'custom', ctx.author.id, ctx.author)
        if conflict_msg:
            try:
                await ctx.author.send(conflict_msg)
            except discord.Forbidden:
                pass
            await ctx.send("❌ Username conflict detected! Check your DMs.")
            return

        # Validate prediction against options if they exist
        custom_options = prediction_systems['custom']['options']
        if custom_options and prediction.lower() not in [opt.lower() for opt in custom_options]:
            options_text = ", ".join(custom_options)
            await ctx.send(f"❌ Invalid prediction! Please choose from: **{options_text}**")
            return

        user_id = ctx.author.id
        predictions = prediction_systems['custom']['predictions']

        # Check if user already made a prediction
        if user_id in predictions:
            old_prediction = predictions[user_id]["prediction"]
            predictions[user_id] = {"prediction": prediction, "user": ctx.author, "kick_username": kick_username}

            # Send DM confirmation
            try:
                await ctx.author.send(f"✅ **Custom Prediction Updated!**\nChanged from **{old_prediction}** to **{prediction}**")
            except discord.Forbidden:
                pass  # User has DMs disabled

        else:
            # Register username
            await UserValidator.register_username(kick_username, 'custom', ctx.author.id, ctx.author)
            
            predictions[user_id] = {"prediction": prediction, "user": ctx.author, "kick_username": kick_username}

            # Record user participation
            await StatisticsManager.record_user_participation(kick_username, ctx.author.id, 'custom')

            # Send DM confirmation
            try:
                await ctx.author.send(f"✅ **Custom Prediction Confirmed!**\nYou predicted **{prediction}**")
            except discord.Forbidden:
                pass  # User has DMs disabled

        # Show current prediction count and list of kick usernames
        total_predictions = len(predictions)
        kick_usernames = [data["kick_username"] for data in predictions.values()]
        usernames_list = ", ".join(kick_usernames)

        await ctx.send(f"🎯 **{total_predictions}** player(s) have made custom predictions!\n🎮 **Players:** {usernames_list}")
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def open_custom_predictions(self, ctx, duration: int = 0, *, question_and_options: str = ""):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        
        # Parse question and options
        question = "Custom Question"
        options = []
        
        if question_and_options:
            # Format: "What color? | red | blue | green"
            parts = [part.strip() for part in question_and_options.split('|')]
            if len(parts) >= 2:
                question = parts[0]
                options = parts[1:]

        prediction_systems['custom']['active'] = True
        prediction_systems['custom']['question'] = question
        prediction_systems['custom']['options'] = options
        prediction_systems['custom']['predictions'].clear()
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('custom')
        
        # Set custom duration if provided
        if duration and duration > 0:
            TimerManager.set_custom_duration('custom', duration)
        
        # Get effective duration
        duration_minutes = TimerManager.get_custom_duration('custom')
        
        # Start timer
        await TimerManager.start_prediction_timer('custom', ctx, duration_minutes=duration_minutes)
        
        # Start activity monitoring
        await ActivityMonitor.start_reminder_monitoring('custom', ctx.channel)
        
        # Create embed for custom prediction
        embed = discord.Embed(
            title="✅ **Custom Predictions are now OPEN!** 🎯",
            description=f"**Question:** {question}",
            color=0x9932CC
        )
        
        if options:
            options_text = ", ".join(options)
            embed.add_field(name="📝 Options", value=f"**{options_text}**", inline=False)
            command_text = f"`!predictcustom option YourKickUsername`"
        else:
            command_text = f"`!predictcustom answer YourKickUsername`"
        
        embed.add_field(name="🎮 How to Participate", value=command_text, inline=False)
        
        timestamp_str = TimerManager.get_discord_timestamp('custom') or f"in {duration_minutes} minutes"
        embed.add_field(name="⏰ Auto-closes", value=timestamp_str, inline=False)
        
        message = await ctx.send(embed=embed)
        
        # Delete this message when predictions close
        await AdminUtils.schedule_message_deletion(message, 'custom')
        
        # Record statistics
        await StatisticsManager.record_prediction_opened('custom')
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def close_custom_predictions(self, ctx):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        from main import prediction_systems
        prediction_systems['custom']['active'] = False
        prediction_count = len(prediction_systems['custom']['predictions'])
        
        # Cancel timer and stop activity monitoring
        TimerManager.cancel_timer('custom')
        ActivityMonitor.stop_reminder_monitoring('custom')
        
        # Delete pending messages
        await AdminUtils.delete_pending_messages('custom')
        
        # Clear usernames from validator
        await UserValidator.clear_system_usernames('custom')
        
        await ctx.send(f"🔒 **Custom predictions are now CLOSED!** ({prediction_count} predictions recorded)")
        
        # Save data
        await PersistenceManager.save_data()

    @commands.command()
    async def custom_result(self, ctx, *, winning_answer: str = ""):
        if not await AdminUtils.check_admin_permission(ctx):
            return

        if not winning_answer:
            await ctx.send("❌ Please specify the winning answer: `!custom_result answer`")
            return

        # Announce result
        await ctx.send(f"🎯 **Custom Prediction Result:** **{winning_answer}** 🔧")

        # Check for winners if predictions were made
        from main import prediction_systems
        if prediction_systems['custom']['predictions']:
            await self.check_custom_prediction_winners(ctx, winning_answer)

async def setup(bot):
    await bot.add_cog(CustomPredictionCog(bot))
