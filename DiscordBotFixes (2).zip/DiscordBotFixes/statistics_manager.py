import json
import asyncio
from datetime import datetime
from typing import Dict, List, Any
from collections import defaultdict

class StatisticsManager:
    """Manages comprehensive statistics for the prediction bot"""
    
    # Persistent statistics
    total_predictions_opened = 0
    total_users_joined = 0
    total_users_won = 0
    total_users_lost = 0
    user_win_counts = defaultdict(int)  # kick_username -> win_count
    user_participation_counts = defaultdict(int)  # kick_username -> participation_count
    prediction_history = []  # List of completed predictions
    daily_stats = defaultdict(lambda: {"predictions": 0, "participants": 0, "winners": 0})
    
    @staticmethod
    async def initialize():
        """Initialize the statistics manager"""
        print("Statistics Manager initialized")
    
    @staticmethod
    async def record_prediction_opened(system_name: str):
        """Record when a prediction is opened"""
        StatisticsManager.total_predictions_opened += 1
        
        # Record daily stats
        today = datetime.now().strftime("%Y-%m-%d")
        StatisticsManager.daily_stats[today]["predictions"] += 1
        
        # Save data
        from persistence_manager import PersistenceManager
        await PersistenceManager.save_data()
    
    @staticmethod
    async def record_user_participation(kick_username: str, user_id: int, system_name: str):
        """Record when a user participates in a prediction"""
        StatisticsManager.user_participation_counts[kick_username] += 1
        
        # Update total unique users (simplified)
        StatisticsManager.total_users_joined = len(StatisticsManager.user_participation_counts)
        
        # Record daily stats
        today = datetime.now().strftime("%Y-%m-%d")
        StatisticsManager.daily_stats[today]["participants"] += 1
    
    @staticmethod
    async def record_prediction_result(system_name: str, winner_usernames: List[str], all_participants: List[str]):
        """Record the result of a completed prediction"""
        # Record winners
        for username in winner_usernames:
            StatisticsManager.user_win_counts[username] += 1
            StatisticsManager.total_users_won += 1
        
        # Record losers
        losers = [username for username in all_participants if username not in winner_usernames]
        StatisticsManager.total_users_lost += len(losers)
        
        # Record daily stats
        today = datetime.now().strftime("%Y-%m-%d")
        StatisticsManager.daily_stats[today]["winners"] += len(winner_usernames)
        
        # Record prediction history
        prediction_record = {
            "system": system_name,
            "timestamp": datetime.now().isoformat(),
            "winners": winner_usernames,
            "total_participants": len(all_participants),
            "winner_count": len(winner_usernames)
        }
        StatisticsManager.prediction_history.append(prediction_record)
        
        # Keep only last 100 records to prevent excessive memory usage
        if len(StatisticsManager.prediction_history) > 100:
            StatisticsManager.prediction_history = StatisticsManager.prediction_history[-100:]
        
        # Save data
        from persistence_manager import PersistenceManager
        await PersistenceManager.save_data()
    
    @staticmethod
    async def get_overall_statistics() -> Dict[str, Any]:
        """Get comprehensive statistics"""
        # Find top winner
        top_winner = None
        if StatisticsManager.user_win_counts:
            top_winner_username = max(StatisticsManager.user_win_counts.keys(), key=lambda k: StatisticsManager.user_win_counts[k])
            top_winner = {
                "username": top_winner_username,
                "wins": StatisticsManager.user_win_counts[top_winner_username]
            }
        
        return {
            "total_predictions_opened": StatisticsManager.total_predictions_opened,
            "total_users_joined": StatisticsManager.total_users_joined,
            "total_users_won": StatisticsManager.total_users_won,
            "total_users_lost": StatisticsManager.total_users_lost,
            "top_winner": top_winner,
            "recent_predictions": StatisticsManager.prediction_history[-10:],  # Last 10
            "daily_stats": dict(StatisticsManager.daily_stats)
        }
    
    @staticmethod
    async def get_user_statistics(kick_username: str) -> Dict[str, Any]:
        """Get statistics for a specific user"""
        return {
            "participation_count": StatisticsManager.user_participation_counts[kick_username],
            "win_count": StatisticsManager.user_win_counts[kick_username],
            "win_rate": (StatisticsManager.user_win_counts[kick_username] / 
                        StatisticsManager.user_participation_counts[kick_username] * 100) 
                       if StatisticsManager.user_participation_counts[kick_username] > 0 else 0
        }
    
    @staticmethod
    async def get_persistent_data() -> Dict[str, Any]:
        """Get data that should be saved to disk"""
        return {
            "total_predictions_opened": StatisticsManager.total_predictions_opened,
            "total_users_joined": StatisticsManager.total_users_joined,
            "total_users_won": StatisticsManager.total_users_won,
            "total_users_lost": StatisticsManager.total_users_lost,
            "user_win_counts": dict(StatisticsManager.user_win_counts),
            "user_participation_counts": dict(StatisticsManager.user_participation_counts),
            "prediction_history": StatisticsManager.prediction_history,
            "daily_stats": dict(StatisticsManager.daily_stats)
        }
    
    @staticmethod
    async def load_persistent_data(data: Dict[str, Any]):
        """Load saved statistics data"""
        StatisticsManager.total_predictions_opened = data.get("total_predictions_opened", 0)
        StatisticsManager.total_users_joined = data.get("total_users_joined", 0)
        StatisticsManager.total_users_won = data.get("total_users_won", 0)
        StatisticsManager.total_users_lost = data.get("total_users_lost", 0)
        
        StatisticsManager.user_win_counts = defaultdict(int, data.get("user_win_counts", {}))
        StatisticsManager.user_participation_counts = defaultdict(int, data.get("user_participation_counts", {}))
        StatisticsManager.prediction_history = data.get("prediction_history", [])
        StatisticsManager.daily_stats = defaultdict(lambda: {"predictions": 0, "participants": 0, "winners": 0}, 
                                                   data.get("daily_stats", {}))
